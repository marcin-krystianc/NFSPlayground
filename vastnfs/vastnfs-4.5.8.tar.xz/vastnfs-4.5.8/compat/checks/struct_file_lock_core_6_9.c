#include <linux/module.h>
#include <linux/filelock.h>

/*
 * v6.9-rc1~218^2~4^2~30: "filelock: split common fields into struct file_lock_core"
 */
int test_dummy(struct file_lock_core* ptr)
{
	return sizeof(*ptr);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
