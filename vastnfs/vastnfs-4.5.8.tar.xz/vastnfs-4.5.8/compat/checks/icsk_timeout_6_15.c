#include <linux/module.h>
#include <net/inet_connection_sock.h>

/*
 * v6.15-rc1~160^2~9^2~1: tcp/dccp: remove icsk->icsk_timeout
 */
unsigned long test_dummy(const struct inet_connection_sock *icsk)
{
	return icsk_timeout(icsk);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
