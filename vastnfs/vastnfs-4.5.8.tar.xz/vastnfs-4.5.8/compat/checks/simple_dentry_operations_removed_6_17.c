#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.17-rc1~233^2~5 "kill simple_dentry_operations"
 */
int test_dummy(void)
{
	extern const struct dentry_operations simple_dentry_operations;
	return 0;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");