#include <linux/module.h>
#include <linux/security.h>
/*
 * v6.14-rc1~166^2~12: "lsm: use lsm_context in security_inode_getsecctx"
 */
size_t test_dummy(const struct lsm_context *lsmcxt)
{
	return sizeof(*lsmcxt);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
