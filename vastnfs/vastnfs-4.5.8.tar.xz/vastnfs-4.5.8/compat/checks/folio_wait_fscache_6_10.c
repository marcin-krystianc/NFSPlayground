#include <linux/module.h>
#include <linux/pagemap.h>
#include <linux/netfs.h>
/*
 * v6.10-rc1~222^2~1^2~19: "mm: Remove the PG_fscache alias for PG_private_2"
 */
void test_dummy(struct folio *folio)
{
	return folio_wait_fscache(folio);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
