#include <linux/module.h>
#include <linux/fs.h>
#include <linux/posix_acl_xattr.h>

/*
 * v6.4-rc1~193^2~3 "fs: rename generic posix acl handlers"
 */
const struct xattr_handler *test_dummy(void)
{
	return &posix_acl_access_xattr_handler;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
