#include <linux/module.h>
#include <linux/fs.h>

/*
 * v5.15-rc1~130^2~1 "vfs: add rcu argument to ->get_acl() callback"
 */
struct posix_acl *test_dummy(struct inode_operations *ops, struct inode *inode, int type)
{
	return ops->get_acl(inode, type);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
