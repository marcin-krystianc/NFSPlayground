#include <linux/module.h>
#include <linux/fs.h>
#include <linux/fsnotify.h>

/*
 * v6.10-rc1~90^2~8: "fsnotify: create a wrapper fsnotify_find_inode_mark()"
 */
struct fsnotify_mark *test_dummy(struct inode *inode,
				struct fsnotify_group *group)
{
	return fsnotify_find_inode_mark(inode, group);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
