#include <linux/module.h>
#include <linux/dcache.h>

/*
 * v6.14-rc1~38^2~13: "Pass parent directory inode and expected name to ->d_revalidate()"
 */
typedef int (*test_revalidate_t)(struct inode *, const struct qstr *,
					struct dentry *, unsigned int);
test_revalidate_t test_dummy(const struct dentry_operations* ops)
{
	return ops->d_revalidate;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
