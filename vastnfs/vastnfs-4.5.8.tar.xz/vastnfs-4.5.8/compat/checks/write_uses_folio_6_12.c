#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.12-rc1~214^2~2^2~2: "fs: Convert aops->write_begin to take a folio"
 */
typedef int (*test_write_begin_t)(struct file *, struct address_space *,
				loff_t, unsigned, struct folio **, void **);
test_write_begin_t test_dummy(struct address_space_operations *aops)
{
	return aops->write_begin;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
