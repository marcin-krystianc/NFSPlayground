#include <linux/module.h>
#include <linux/blkdev.h>
#include <linux/fs.h>

/*
 * v6.9-rc1~217^2^2~31 "bdev: open block device as files"
 */
struct file *test_dummy(dev_t dev, blk_mode_t mode, void *holder,
			const struct blk_holder_ops *hops)
{
	return bdev_file_open_by_dev(dev, mode, holder, hops);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
