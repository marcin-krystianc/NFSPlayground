#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.19-rc1~111^2~2: convert securityfs
 * simple_start_creating() function introduced for simplified dentry creation
 */
struct dentry *test_dummy(struct dentry *parent, const char *name)
{
	return simple_start_creating(parent, name);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");