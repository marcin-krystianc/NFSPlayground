#include <linux/module.h>
#include <linux/shrinker.h>

/*
 * v6.7-rc1~90^2~353: "mm: shrinker: add infrastructure for dynamically allocating shrinker"
 */
const void* test_dummy(void)
{
	return shrinker_alloc;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
