#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.1-rc7~1^2 "vfs: fix copy_file_range() averts filesystem freeze protection"
 */
int test_dummy(void)
{
	return COPY_FILE_SPLICE;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
