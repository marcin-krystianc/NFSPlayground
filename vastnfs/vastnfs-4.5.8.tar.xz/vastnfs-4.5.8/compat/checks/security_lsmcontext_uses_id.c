#include <linux/module.h>
#include <linux/security.h>

#include "../../compat.h"

/* LAYER: 2 */

#ifdef COMPAT_DETECT_SECURITY_UBUNTU_LSMCONTEXT
size_t test_dummy(const struct lsmcontext *lsmcxt)
#else /* !COMPAT_DETECT_SECURITY_UBUNTU_LSMCONTEXT */
size_t test_dummy(const struct lsm_context *lsmcxt)
#endif /* COMPAT_DETECT_SECURITY_UBUNTU_LSMCONTEXT */
{
	return lsmcxt->id;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
