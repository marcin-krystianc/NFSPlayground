#include <linux/fs.h>

/*
 * v6.19-rc1~250^2~4: hide ->i_state behind accessors
 * inode state changed from unsigned long to struct inode_state_flags with __state member
 */
void test(void)
{
	struct inode *inode = NULL;
	unsigned long state = inode->i_state.__state;
	(void)state;
}