#include <linux/fs.h>

/*
 * v6.19-rc1~241^2~2^2~7: vfs: make vfs_create break delegations on parent directory
 * vfs_create() signature changed to use delegated_inode parameter
 */
void test(void)
{
	struct mnt_idmap *idmap = NULL;
	struct dentry *dentry = NULL;
	struct delegated_inode *delegated = NULL;
	vfs_create(idmap, dentry, 0, delegated);
}