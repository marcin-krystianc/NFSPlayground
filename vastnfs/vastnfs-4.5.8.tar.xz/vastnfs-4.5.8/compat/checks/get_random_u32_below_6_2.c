#include <linux/module.h>
#include <linux/random.h>

/*
 * v6.2-rc1~171^2~21 "random: use rejection sampling for uniform bounded random integers"
 */
u32 test_dummy(u32 ceil)
{
	return get_random_u32_below(ceil);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
