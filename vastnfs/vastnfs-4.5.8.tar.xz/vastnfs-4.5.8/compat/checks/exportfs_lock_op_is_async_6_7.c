#include <linux/module.h>
#include <linux/exportfs.h>

/*
 * exportfs_lock_op_is_async() function introduction - around v6.7
 */
bool test_dummy(void)
{
	return exportfs_lock_op_is_async(NULL);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");