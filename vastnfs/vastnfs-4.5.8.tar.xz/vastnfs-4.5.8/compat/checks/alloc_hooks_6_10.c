#include <linux/module.h>
#include <linux/slab.h>

/*
 * v6.10-rc1~105^2~381: "mm: enable page allocation tagging"
 */
void test_dummy(void)
{
	void *ptr = alloc_hooks(kmalloc(64, GFP_KERNEL));
	kfree(ptr);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
