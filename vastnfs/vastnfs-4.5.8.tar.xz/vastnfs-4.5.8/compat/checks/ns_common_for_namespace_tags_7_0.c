#include <linux/module.h>
#include <linux/sysfs.h>

/*
 * v7.0~17^2~2: "kernfs: pass struct ns_common instead of const void * for namespace tags"
 */

const struct ns_common *namespace_func(const struct kobject *kobj);
const struct ns_common *namespace_func(const struct kobject *kobj)
{
	return NULL;
}

void *test_dummy(void);
void *test_dummy(void)
{
	struct kobj_type ktype = {
		.namespace = namespace_func,
	};

	return (void *)ktype.namespace;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
