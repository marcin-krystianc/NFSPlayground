#include <linux/module.h>
#include <net/tcp.h>

/*
 * v6.19-rc1~170^2~68^2~3: tcp: rename icsk_timeout() to tcp_timeout_expires()
 * This checks if tcp_timeout_expires() function exists
 */
unsigned long test_dummy(const struct sock *sk)
{
	return tcp_timeout_expires(sk);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");