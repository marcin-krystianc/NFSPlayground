#include <linux/module.h>
#include <linux/percpu_counter.h>

/*
 * v6.6-rc1~94^2~1 "pcpcntr: add group allocation/free"
 */
int test_dummy(struct percpu_counter *fbc, s64 amount, gfp_t gfp,
		      u32 nr_counters)
{
	return percpu_counter_init_many(fbc, amount, gfp, nr_counters);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
