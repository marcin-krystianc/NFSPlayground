#include <linux/module.h>
#include <linux/uio.h>

/*
 * v6.0-rc1~55^2~31 "new iov_iter flavour - ITER_UBUF"
 */
bool test_dummy(struct iov_iter *i)
{
	return iter_is_ubuf(i);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
