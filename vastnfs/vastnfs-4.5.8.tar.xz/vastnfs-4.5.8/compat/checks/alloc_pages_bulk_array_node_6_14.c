#include <linux/module.h>
#include <linux/gfp.h>

/*
 * v6.14-rc1~77^2~105: "mm: alloc_pages_bulk: rename API"
 */
unsigned long test_dummy(int node, unsigned long nr_pages, struct page **page_array)
{
	return alloc_pages_bulk_array_node(GFP_KERNEL, node, nr_pages, page_array);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
