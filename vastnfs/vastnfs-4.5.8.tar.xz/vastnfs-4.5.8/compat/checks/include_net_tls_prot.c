#include <linux/module.h>
#include <net/tls_prot.h>

/* v6.6-rc1~162^2~297^2~6 nnet/tls: Move TLS protocol elements to a separate header */
int test_dummy(void) { return 0; }
EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
