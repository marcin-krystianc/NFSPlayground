#include <linux/module.h>
#include <linux/pagemap.h>

/*
 * v6.15-rc1~81^2~306 "fs: remove folio_file_mapping()"
 */
struct address_space *test_dummy(struct folio *folio)
{
	return folio_file_mapping(folio);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
