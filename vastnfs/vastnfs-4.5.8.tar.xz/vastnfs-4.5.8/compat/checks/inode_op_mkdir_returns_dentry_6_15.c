#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.15-rc1~10^2~9 "Change inode_operations.mkdir to return struct dentry *"
 */
struct dentry *test_dummy(struct mnt_idmap *idmap, struct inode *dir,
				 struct dentry *dentry, umode_t mode)
{
	/* Test if mkdir operation returns struct dentry * */
	return NULL;
}

const struct inode_operations test_iops = {
	.mkdir = test_dummy,
};

EXPORT_SYMBOL(test_iops);
MODULE_LICENSE("GPL");