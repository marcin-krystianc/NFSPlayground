#include <linux/module.h>
#include <linux/kobject.h>

/*
 * v6.2-rc1~66^2~20 "kobject: make kobject_get_ownership() take a constant kobject *"
 */
typedef void (*test_t)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);

test_t test_dummy(void)
{
	return kobject_get_ownership;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
