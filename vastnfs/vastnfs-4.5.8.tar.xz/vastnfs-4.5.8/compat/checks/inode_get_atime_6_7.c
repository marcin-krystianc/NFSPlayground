#include <linux/module.h>
#include <linux/fs.h>

void test_dummy(struct inode *inode, struct timespec64 ts)
{
	inode_set_atime_to_ts(inode, ts);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
