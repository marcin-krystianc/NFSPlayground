#include <linux/module.h>
#include <net/net_namespace.h>

/* v6.2-rc1~99^2~388: net: add a refcount tracker for kernel sockets */

void test_dummy(struct net *net,
		netns_tracker *tracker,
		bool refcounted)
{
	__netns_tracker_free(net, tracker, refcounted);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
