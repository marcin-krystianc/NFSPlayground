#include <linux/module.h>
#include <linux/string.h>

/*
 * v6.12-rc1~151^2~2 "lib/string_choices: Add str_true_false()/str_false_true()
 */
const char *test_dummy(void)
{
	return str_false_true(1);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
