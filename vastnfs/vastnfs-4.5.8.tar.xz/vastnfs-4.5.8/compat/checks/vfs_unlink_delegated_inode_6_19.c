#include <linux/fs.h>

/*
 * v6.19-rc1~241^2~2^2: VFS delegation breaking changes for directory operations
 * vfs_unlink() takes delegated_inode parameter
 */
void test(void)
{
	struct mnt_idmap *idmap = NULL;
	struct inode *dir = NULL;
	struct dentry *dentry = NULL;
	struct delegated_inode *delegated = NULL;
	vfs_unlink(idmap, dir, dentry, delegated);
}