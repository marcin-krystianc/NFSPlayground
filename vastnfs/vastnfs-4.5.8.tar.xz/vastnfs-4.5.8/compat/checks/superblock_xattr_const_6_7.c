#include <linux/module.h>
#include <linux/fs.h>

/*
 *  CFLAGS: -Werror=discarded-qualifiers
 *
 *  v6.7-rc1~206^2~29: "xattr: make the xattr array itself const"
 */
void test_dummy(struct super_block *sb, const struct xattr_handler * const *s_xattr)
{
	sb->s_xattr = s_xattr;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
