#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.18-rc1~242^2~4 "fs: rename generic_delete_inode() and generic_drop_inode()"
 */
int test_dummy(struct inode *inode)
{
	return generic_drop_inode(inode);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
