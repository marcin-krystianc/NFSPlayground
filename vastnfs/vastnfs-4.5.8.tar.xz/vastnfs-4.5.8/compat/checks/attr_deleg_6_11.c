#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.11-rc6~28^2: "fs/nfsd: fix update of inode attrs in CB_GETATTR"
 */
unsigned int test_dummy(void)
{
	return ATTR_DELEG;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
