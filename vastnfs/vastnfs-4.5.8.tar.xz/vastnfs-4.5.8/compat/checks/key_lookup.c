#include <linux/module.h>
#include <linux/key.h>

/* v6.7:  037c34318a47 ("security/keys: export key_lookup()") */

void *test_dummy(void)
{
	return key_lookup(1);
}

MODULE_LICENSE("GPL");
