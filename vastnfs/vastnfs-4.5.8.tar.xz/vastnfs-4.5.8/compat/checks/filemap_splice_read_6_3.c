#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.3-rc1~136^2~19 ""
 */
ssize_t test_dummy(struct file *in, loff_t *off, struct pipe_inode_info *info,
                   				size_t len, unsigned int flags)
{
	return filemap_splice_read(in, off, info, len, flags);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
