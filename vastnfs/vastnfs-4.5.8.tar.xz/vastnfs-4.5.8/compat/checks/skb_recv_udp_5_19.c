#include <linux/module.h>
#include <net/udp.h>

/*
 * v5.19-rc1~159^2~338 "net: remove noblock parameter from recvmsg() entities"
 */
struct sk_buff* test_dummy(struct sock *sk, unsigned int flags, int *err)
{
	return skb_recv_udp(sk, flags, err);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
