#include <linux/module.h>
#include <linux/fs.h>
#include <linux/pagemap.h>

/*
 * v6.17-rc1~225^2~2^2~2 "fs: change write_begin/write_end interface to take struct kiocb *"
 */
int test_dummy(const struct kiocb *iocb, struct address_space *mapping,
		      loff_t pos, unsigned len, struct folio **foliop, void **fsdata)
{
	struct address_space_operations ops = {
		.write_begin = test_dummy,
	};
	return 0;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");