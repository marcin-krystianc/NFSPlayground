#include <linux/module.h>
#include <linux/uio.h>

/*
 * "iov_iter: Add copy_folio_from_iter_atomic()"
 */
size_t test_dummy(struct folio *folio, size_t offset, size_t bytes, struct iov_iter *i)
{
	return copy_folio_from_iter_atomic(folio, offset, bytes, i);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
