#include <linux/module.h>
#include <linux/blkdev.h>

/*
 * v6.7-rc1~210^2~36: "block: Provide bdev_open_* functions"
 */
size_t test_dummy(struct bdev_handle *handle)
{
	bdev_release(handle);
	return sizeof(*handle);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
