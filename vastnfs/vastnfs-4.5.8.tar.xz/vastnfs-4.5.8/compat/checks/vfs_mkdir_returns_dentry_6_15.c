#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.15-rc1~247^2~1^2 "VFS: Change vfs_mkdir() to return the dentry."
 */
struct dentry test_dummy(struct mnt_idmap *idmap, struct inode *dir,
				struct dentry *dentry, umode_t mode)
{
	return *vfs_mkdir(idmap, dir, dentry, mode);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
