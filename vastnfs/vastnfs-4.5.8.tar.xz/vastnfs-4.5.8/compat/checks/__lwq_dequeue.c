#include <linux/module.h>
#include <linux/slab.h>

struct llist_node *__lwq_dequeue(struct lwq *q);

/*
 * ???
 */
void test_dummy(void)
{
	__lwq_dequeue(NULL);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
