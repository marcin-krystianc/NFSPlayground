#include <linux/module.h>
#include <linux/security.h>

size_t test_dummy(const struct lsmcontext *lsmcxt)
{
	return sizeof(*lsmcxt);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
