#include <linux/module.h>
#include <linux/writeback.h>

/*
 * v6.18-rc1~130^2~246 "mm: remove write_cache_pages"
 */
int test_dummy(struct address_space *mapping,
		      struct writeback_control *wbc,
		      writepage_t writepage, void *data)
{
	return write_cache_pages(mapping, wbc, writepage, data);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
