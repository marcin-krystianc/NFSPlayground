#include <linux/module.h>
#include <linux/exportfs.h>

/*
 * exportfs_can_decode_fh() function introduction - around v6.7
 */
bool test_dummy(void)
{
	return exportfs_can_decode_fh(NULL);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");