#include <linux/module.h>
#include <linux/hex.h>

/*
 * v6.4-rc1~102^2~32: "kernel.h: split the hexadecimal related helpers to hex.h"
 */
const void* test_dummy(void)
{
	return NULL;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
