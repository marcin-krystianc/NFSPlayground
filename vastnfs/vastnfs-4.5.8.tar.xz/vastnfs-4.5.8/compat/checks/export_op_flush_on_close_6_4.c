#include <linux/module.h>
#include <linux/exportfs.h>

/*
 * v6.4-rc1~77^2~23 "nfsd: allow reaping files still under writeback"
 */
int check_type(void)
{
	return EXPORT_OP_FLUSH_ON_CLOSE;
}

EXPORT_SYMBOL(check_type);
MODULE_LICENSE("GPL");
