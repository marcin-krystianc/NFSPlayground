#include <linux/module.h>
#include <linux/fs.h>
#include <linux/namei.h>

/*
 * v6.17-rc1~231^2~8: rpc_pipe: don't overdo directory locking
 * try_lookup_noperm() function introduced for no-permission lookups
 */
struct dentry *test_dummy(struct qstr *name, struct dentry *base)
{
	return try_lookup_noperm(name, base);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");