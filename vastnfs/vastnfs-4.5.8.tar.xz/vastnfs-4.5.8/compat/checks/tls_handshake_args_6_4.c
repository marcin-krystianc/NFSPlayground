#include <linux/module.h>
#include <linux/key.h>
#include <net/handshake.h>

/*
 * v6.4-rc1~77^2~80^2~1 "net/handshake: Add a kernel API for requesting a TLSv1.3 handshake"
 */
struct tls_handshake_args* test_dummy(void)
{
	return NULL;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
