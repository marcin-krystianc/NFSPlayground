#include <linux/module.h>
#include <linux/pagemap.h>

/*
 * v6.7-rc1~90^2~161 "mm: add folio_end_read()"
 */
void test_dummy(struct folio *folio, bool success)
{
	folio_end_read(folio, success);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
