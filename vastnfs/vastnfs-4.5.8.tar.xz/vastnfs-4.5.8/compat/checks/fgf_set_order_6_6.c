#include <linux/module.h>
#include <linux/pagemap.h>

/*
 * v6.5-rc3-8-g4f66170119107 "filemap: Allow __filemap_get_folio to allocate large folios"
 */
fgf_t test_dummy(size_t size)
{
	return fgf_set_order(size);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
