#include <linux/module.h>
#include <linux/fs_context.h>

/*
 * v6.18-rc1~127^2~1 "change the calling conventions for vfs_parse_fs_string()"
 */
int test_dummy(struct fs_context *fc, const char *key,
		      const char *value, size_t v_size)
{
	return vfs_parse_fs_string(fc, key, value, v_size);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
