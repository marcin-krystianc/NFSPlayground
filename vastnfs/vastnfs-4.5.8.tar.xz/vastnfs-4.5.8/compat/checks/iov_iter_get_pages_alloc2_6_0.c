#include <linux/module.h>
#include <linux/uio.h>

/*
 * v6.0-rc1~55^2~11 "iov_iter: advancing variants of iov_iter_get_pages{,_alloc}()"
 */
ssize_t test_dummy(struct iov_iter *i, struct page ***pages,
				size_t maxsize, size_t *start)
{
	return iov_iter_get_pages_alloc2(i, pages, maxsize, start);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
