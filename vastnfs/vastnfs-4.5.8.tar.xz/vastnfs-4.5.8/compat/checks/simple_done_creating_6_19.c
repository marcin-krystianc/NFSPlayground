#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.19-rc1~111^2~2: convert securityfs
 * simple_done_creating() function introduced for simplified dentry creation
 */
void test_dummy(struct dentry *dentry)
{
	simple_done_creating(dentry);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");