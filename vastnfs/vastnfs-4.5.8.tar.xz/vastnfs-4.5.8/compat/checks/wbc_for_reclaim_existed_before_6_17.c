#include <linux/module.h>
#include <linux/writeback.h>

/*
 * v6.17-rc1~84^2~347 "mm: remove the for_reclaim field from struct writeback_control"
 */
int test_dummy(struct writeback_control *wbc)
{
	return wbc->for_reclaim;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");