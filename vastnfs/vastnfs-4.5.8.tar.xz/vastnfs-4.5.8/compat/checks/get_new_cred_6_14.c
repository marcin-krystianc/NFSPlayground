#include <linux/module.h>
#include <linux/cred.h>

/*
 * v6.14-rc1~214^2~1^2: "cred: remove unused get_new_cred()"
 *
 * This check is indicative of whether `Merge patch series "cred:
 * rework {override,revert}_creds()"` (252120f79a301) is merged.
 */
struct cred *test_dummy(struct cred *cred)
{
	return get_new_cred(cred);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
