#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.9-rc1~218^2~3: "filelock: don't do security checks on nfsd setlease calls"
 */
void test_dummy(void)
{
	int result = kernel_setlease(NULL, F_UNLCK, NULL, NULL);
	(void)result;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
