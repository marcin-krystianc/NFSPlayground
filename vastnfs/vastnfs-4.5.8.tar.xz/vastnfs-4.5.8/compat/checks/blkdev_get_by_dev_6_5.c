#include <linux/module.h>
#include <linux/blkdev.h>

/*
 * v6.5-rc1~114^2~52 "block: replace fmode_t with a block-specific type for block open flags"
 */
struct block_device *
test_dummy(dev_t dev, blk_mode_t mode, void *holder, const struct blk_holder_ops *hops)
{
	return blkdev_get_by_dev(dev, mode, holder, hops);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
