#include <linux/module.h>
#include <linux/fs.h>
#include <linux/posix_acl.h>

/*
 * v6.2-rc1~158^2~20 "acl: add vfs_get_acl()"
 */
struct posix_acl *test_dummy(struct inode *inode, int type)
{
	return get_inode_acl(inode, type);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
