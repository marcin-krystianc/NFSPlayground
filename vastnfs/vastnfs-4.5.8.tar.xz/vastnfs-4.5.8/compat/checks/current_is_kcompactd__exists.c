#include <linux/mm.h>
#include <linux/compaction.h>

/* v6.14-rc6~6^2~17: NFS: fix nfs_release_folio() to not deadlock via kcompactd writeback */

int test_dummy(void)
{	
	return current_is_kcompactd();
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
