#include <linux/module.h>
#include <linux/xattr.h>

/*
 * "fs: drop the timespec64 arg from generic_update_time"
 */
int test_wrapper(struct inode *inode, int flags)
{
	return inode_update_timestamps(inode, flags);
}

EXPORT_SYMBOL(test_wrapper);
MODULE_LICENSE("GPL");
