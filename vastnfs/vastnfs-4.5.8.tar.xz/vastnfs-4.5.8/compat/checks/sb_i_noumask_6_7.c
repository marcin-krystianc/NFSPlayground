#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.7-rc1~208^2~22: "fs: add a new SB_I_NOUMASK flag"
 */
int test_dummy(void)
{
	return SB_I_NOUMASK;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
