#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.19-rc1~111^2~2: convert securityfs  
 * d_make_persistent() function introduced for persistent dentries
 */
void test_dummy(struct dentry *dentry, struct inode *inode)
{
	d_make_persistent(dentry, inode);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");