#include <linux/module.h>
#include <linux/fs.h>

/*
 * v7.0-rc1~243^2^2~6 "fs: refactor ->update_time handling"
 */
static int test_dummy(void)
{
	return FS_UPD_ATIME;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
