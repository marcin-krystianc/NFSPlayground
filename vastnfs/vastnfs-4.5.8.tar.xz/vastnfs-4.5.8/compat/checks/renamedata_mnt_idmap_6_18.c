#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.18-rc1~230^2^2~3 "VFS: unify old_mnt_idmap and new_mnt_idmap in renamedata"
 */
int test_dummy(struct mnt_idmap *idmap)
{
	struct renamedata rd = {
		.mnt_idmap = idmap,
	};
	return 0;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
