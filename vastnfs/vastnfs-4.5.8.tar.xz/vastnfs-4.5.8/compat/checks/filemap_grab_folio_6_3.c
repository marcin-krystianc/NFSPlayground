#include <linux/module.h>
#include <linux/pagemap.h>

/*
 * v6.3-rc1~113^2~266 "pagemap: add filemap_grab_folio()"
 */
struct folio * test_dummy(struct address_space *mapping, pgoff_t index)
{
	return filemap_grab_folio(mapping, index);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
