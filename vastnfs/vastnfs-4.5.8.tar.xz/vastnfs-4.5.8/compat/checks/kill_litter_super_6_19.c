#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.19-rc1~111^2~3 "get rid of kill_litter_super()"
 */

int test_dummy(struct super_block *s)
{
	kill_litter_super(s);
	return 0;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
