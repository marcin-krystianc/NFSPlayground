#include <linux/module.h>
#include <linux/dcache.h>

/*
 * v6.16-rc1~226^2^2~1 ("Use try_lookup_noperm() instead of d_hash_and_lookup() outside of VFS")
 */
struct dentry *test_dummy(struct dentry *parent, struct qstr *name)
{
	return d_hash_and_lookup(parent, name);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");