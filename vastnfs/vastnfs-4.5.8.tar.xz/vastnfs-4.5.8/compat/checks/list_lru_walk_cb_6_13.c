#include <linux/module.h>
#include <linux/list_lru.h>

/*
 * v6.13-rc1~99^2~11: "mm/list_lru: simplify the list_lru walk callback function"
 */
enum lru_status test_cb(struct list_head *item,
				struct list_lru_one *list, void *cb_arg)
{
	return LRU_STOP;
}

list_lru_walk_cb test_dummy(void)
{
	return &test_cb;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
