#include <linux/module.h>
#include <linux/key.h>
#include <linux/socket.h>
#include <net/handshake.h>

/* v6.6-rc1~162^2~297^2~3:  SUNRPC: Send TLS Closure alerts before closing a TCP socket */

void *test_dummy(void)
{
	return &tls_handshake_close;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
