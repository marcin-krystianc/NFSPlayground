#include <linux/module.h>
#include <linux/mm.h>
#include <linux/page-flags.h>

void test_dummy(struct folio *folio, bool success)
{
	folio_set_error(folio);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
