#include <linux/module.h>
#include <linux/ima.h>

/*
 * v6.9-rc1~157^2~8: "ima: Move to LSM infrastructure"
 */
int test_dummy(struct file *file, int mask)
{
	return ima_file_check(file, mask);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
