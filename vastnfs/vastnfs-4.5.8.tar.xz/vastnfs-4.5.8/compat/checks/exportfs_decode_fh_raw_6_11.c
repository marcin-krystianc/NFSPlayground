#include <linux/module.h>
#include <linux/exportfs.h>

/*
 * v6.11-rc1~242^2~23: "fhandle: relax open_by_handle_at() permission checks"
 * exportfs_decode_fh_raw() takes additional @flags parameter
 */
struct dentry *test_dummy(struct vfsmount *mnt, struct fid *fid,
			int fh_len, int fileid_type, unsigned int flags,
			int (*acceptable)(void *, struct dentry *), void *context)
{
	return exportfs_decode_fh_raw(mnt, fid, fh_len, fileid_type, flags, acceptable, context);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
