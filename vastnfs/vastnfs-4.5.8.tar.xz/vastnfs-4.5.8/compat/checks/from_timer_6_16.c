#include <linux/module.h>
#include <linux/timer.h>

struct test_struct {
	struct timer_list timer;
};

/*
 * v6.16-rc1~2^2 ("treewide, timers: Rename from_timer() to timer_container_of()")
 */
void test_dummy(struct timer_list *t)
{
	struct test_struct *test = from_timer(test, t, timer);
	(void)test;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");