#include <linux/module.h>
#include <net/sock.h>

/*
 * v6.14-rc5~23^2~28 "net: better track kernel sockets lifetime"
 */
void test_dummy(struct sock *sk)
{
	sk_net_refcnt_upgrade(sk);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
