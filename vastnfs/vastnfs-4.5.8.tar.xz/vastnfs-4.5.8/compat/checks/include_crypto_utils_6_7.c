#include <linux/module.h>
#include <crypto/utils.h>

/* v6.7-rc1~91^2~247: "SUNRPC: Do not include crypto/algapi.h" */

int test_dummy(void) { return 0; }

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
