#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.19-rc1~241^2~2^2~6: vfs: make vfs_mknod break delegations on parent directory
 * vfs_mkdir() takes delegated_inode parameter and returns struct dentry *
 */
struct dentry *test_dummy(struct mnt_idmap *idmap, struct inode *dir,
				struct dentry *dentry, umode_t mode)
{
	struct delegated_inode *delegated = NULL;
	return vfs_mkdir(idmap, dir, dentry, mode, delegated);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");