#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.17-rc1~233^2~15   "new helper: set_default_d_op()"
 */

int test_dummy(struct super_block *s, const struct dentry_operations *ops)
{
	set_default_d_op(s, ops);
	return 0;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
