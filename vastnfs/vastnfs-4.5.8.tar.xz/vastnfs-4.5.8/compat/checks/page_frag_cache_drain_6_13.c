#include <linux/module.h>
#include <linux/page_frag_cache.h>

/*
 * v6.13-rc1~135^2~89^2~5: "mm: move the page fragment allocator from page_alloc into its own file"
 */
void test_dummy(struct page_frag_cache *nc)
{
	return page_frag_cache_drain(nc);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
