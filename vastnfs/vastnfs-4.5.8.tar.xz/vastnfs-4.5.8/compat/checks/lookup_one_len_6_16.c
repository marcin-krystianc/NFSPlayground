#include <linux/module.h>
#include <linux/namei.h>
#include <linux/fs.h>

/*
 * v6.16-rc1~226^2^2~2 ("VFS: rename lookup_one_len family to lookup_noperm and remove permission check")
 */
struct dentry *test_dummy(const char *name, struct dentry *parent, int len)
{
	return lookup_one_len(name, parent, len);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
