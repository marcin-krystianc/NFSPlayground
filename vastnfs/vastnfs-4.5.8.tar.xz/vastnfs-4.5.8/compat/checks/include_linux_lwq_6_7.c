#include <linux/module.h>
#include <linux/lwq.h>

/*
 * v6.12-rc2~37^2: "move asm/unaligned.h to linux/unaligned.h"
 */
const void* test_dummy(void)
{
	return NULL;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
