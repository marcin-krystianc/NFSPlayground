#include <linux/module.h>
#include <linux/sched.h>

/*
 * v6.4-rc1~193^2~7 "ched: Add test_and_clear_wake_up_bit() and atomic_dec_and_wake_up"
 */
int test_wrapper(atomic_t *var)
{
	store_release_wake_up(var, NULL);
	return 0;
}

EXPORT_SYMBOL(test_wrapper);
MODULE_LICENSE("GPL");
