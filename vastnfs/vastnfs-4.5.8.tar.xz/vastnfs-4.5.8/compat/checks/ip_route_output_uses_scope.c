#include <linux/module.h>
#include <linux/rtnetlink.h>
#include <net/route.h>

/*
 * v6.10-rc1~153^2~326: "ipv4: Set scope explicitly in ip_route_output()"
 */
struct rtable * test_dummy(struct net *net, __be32 daddr, __be32 saddr)
{
	return ip_route_output(net, daddr, saddr, 0, 0, RT_SCOPE_UNIVERSE);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
