#include <linux/module.h>
#include <net/genetlink.h>

/*
 * v6.6-rc1~162^2~117^2~3 "genetlink: add genlmsg_iput() API"
 */
void test_dummy(struct sk_buff *skb, const struct genl_info *info)
{
	genlmsg_iput(skb, info);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
