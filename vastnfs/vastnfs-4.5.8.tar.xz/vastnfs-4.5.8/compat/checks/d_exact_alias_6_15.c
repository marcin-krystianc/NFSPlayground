#include <linux/module.h>
#include <linux/dcache.h>

/*
 * v6.15-rc1~247^2~2^2~1 "nfs/vfs: discard d_exact_alias()"
 */
struct dentry *test_dummy(struct dentry *entry, struct inode *inode)
{
	return d_exact_alias(entry, inode);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
