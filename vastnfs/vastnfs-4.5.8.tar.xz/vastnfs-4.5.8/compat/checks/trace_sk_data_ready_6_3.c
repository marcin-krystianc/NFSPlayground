#include <linux/module.h>
#include <net/sock.h>
#include <trace/events/sock.h>

/*
 * v6.3-rc1~162^2~235 "net/sock: Introduce trace_sk_data_ready()"
 */
void test_dummy(struct sock *sk)
{
	trace_sk_data_ready(sk);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
