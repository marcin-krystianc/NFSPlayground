#include <linux/module.h>
#include <linux/fs.h>
#include <linux/writeback.h>

/*
 * v6.16-rc1~225^2^2 ("fs: Remove aops->writepage")
 */
int test_writepage(struct page *page, struct writeback_control *wbc)
{
	return 0;
}

int test_dummy(void)
{
	/* Try to reference writepage member */
	struct address_space_operations test_aops = {0};
	test_aops.writepage = test_writepage;
	return (test_aops.writepage != NULL) ? 1 : 0;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");