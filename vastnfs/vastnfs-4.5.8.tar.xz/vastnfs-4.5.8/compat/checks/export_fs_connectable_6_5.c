#include <linux/module.h>
#include <linux/exportfs.h>

/*
 * v6.5-rc1~146^2~5 "exportfs: change connectable argument to bit flags"
 */
int check_type(void)
{
	return EXPORT_FH_CONNECTABLE;
}

EXPORT_SYMBOL(check_type);
MODULE_LICENSE("GPL");
