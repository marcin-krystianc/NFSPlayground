#include <linux/module.h>
#include <linux/splice.h>
#include <linux/fs.h>

/*
 * v6.8-rc1~212^2~5 "fs: use splice_copy_file_range() inline helper"
 */
ssize_t test_dummy(struct file *file_in, loff_t pos_in,
			  struct file *file_out, loff_t pos_out, size_t len)
{
	return splice_copy_file_range(file_in, pos_in, file_out, pos_out, len);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
