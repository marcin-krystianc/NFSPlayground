#include <linux/module.h>
#include <linux/fs.h>

/*
 * v7.0-rc1~242^2~1^2 "fs: remove simple_nosetlease()"
 */
static void *test_dummy(void)
{
	return simple_nosetlease;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
