#include <linux/module.h>
#include <linux/slab.h>

/*
 * v6.10-rc1~105^2~374: "mm/slab: enable slab allocation tagging for kmalloc and
 * friends"
 */
void test_dummy(void)
{
	char *data = kmemdup_noprof("test", 4, GFP_KERNEL);
	kfree(data);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
