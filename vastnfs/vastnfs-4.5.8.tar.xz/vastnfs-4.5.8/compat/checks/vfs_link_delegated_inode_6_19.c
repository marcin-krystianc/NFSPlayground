#include <linux/fs.h>

/*
 * v6.19-rc1~241^2~2^2: VFS delegation breaking changes for directory operations
 * vfs_link() takes delegated_inode parameter
 */
void test(void)
{
	struct dentry *old_dentry = NULL;
	struct mnt_idmap *idmap = NULL;
	struct inode *dir = NULL;
	struct dentry *new_dentry = NULL;
	struct delegated_inode *delegated = NULL;
	vfs_link(old_dentry, idmap, dir, new_dentry, delegated);
}