#include <linux/module.h>
#include <linux/filelock.h>

/*
 * v6.3-rc1~221^2~1: "filelock: move file locking definitions to separate header file"
 */
struct file_lock* test_dummy(void)
{
	return NULL;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
