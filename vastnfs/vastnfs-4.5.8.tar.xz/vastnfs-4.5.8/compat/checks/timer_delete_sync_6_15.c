#include <linux/module.h>
#include <linux/timer.h>

/*
 * v6.15-rc1~7^2~10 "treewide: Switch/rename to timer_delete[_sync]("
 */
int test_dummy(struct timer_list *timer)
{
	return timer_delete_sync(timer);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
