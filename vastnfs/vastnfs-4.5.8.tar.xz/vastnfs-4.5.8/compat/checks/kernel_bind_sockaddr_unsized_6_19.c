#include <linux/net.h>

/*
 * v6.19-rc1~170^2~230^2: net: Convert struct sockaddr to fixed-size "sa_data[14]"
 * kernel_bind() now takes sockaddr_unsized instead of sockaddr
 */
void test(void)
{
	struct socket *sock = NULL;
	struct sockaddr_unsized *addr = NULL;
	kernel_bind(sock, addr, 0);
}