#include <linux/module.h>
#include <linux/pagemap.h>

/*
 * v6.10-rc2~33^2~7 "filemap: add helper mapping_max_folio_size()"
 */
size_t test_dummy(struct address_space *mapping)
{
	return mapping_max_folio_size(mapping);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
