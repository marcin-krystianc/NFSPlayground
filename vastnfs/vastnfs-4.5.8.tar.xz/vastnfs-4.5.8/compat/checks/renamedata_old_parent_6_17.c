#include <linux/module.h>
#include <linux/fs.h>

/*
 * v6.17-rc1~223^2~4 "VFS: change old_dir and new_dir in struct renamedata to dentrys"
 */
int test_dummy(struct dentry *parent)
{
	struct renamedata rd = {
		.old_parent = parent,
		.new_parent = parent,
	};
	return 0;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");