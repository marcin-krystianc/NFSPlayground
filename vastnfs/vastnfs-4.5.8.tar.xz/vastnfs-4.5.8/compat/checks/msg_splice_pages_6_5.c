#include <linux/module.h>
#include <linux/socket.h>

/*
 * v6.5-rc1~163^2~235^2~15 "net: Declare MSG_SPLICE_PAGES internal sendmsg() flag"
 */
int check_type(void)
{
	return MSG_SPLICE_PAGES;
}

EXPORT_SYMBOL(check_type);
MODULE_LICENSE("GPL");
