#include <linux/module.h>
#include <linux/llist.h>

/*
 * v6.7-rc1~204^2~108: "llist: add llist_del_first_this()"
 */
bool test_dummy(struct llist_head *head, struct llist_node *node)
{
	return llist_del_first_this(head, node);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");