#include <linux/module.h>
#include <linux/sysctl.h>

/*
 * v6.11-rc1~43^2: "sysctl: treewide: constify the ctl_table argument of proc_handlers"
 */
typedef int (*proc_handler_test_t)(const struct ctl_table *ctl, int write,
				void *buffer, size_t *lenp, loff_t *ppos);
proc_handler_test_t test_dummy(struct ctl_table* hdr)
{
	return hdr->proc_handler;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
