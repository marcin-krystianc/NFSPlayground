#include <linux/module.h>
#include <linux/key.h>
#include <linux/socket.h>
#include <net/handshake.h>

/* v6.6-rc1~162^2~297^2~2: net/handshake: Add helpers for parsing incoming TLS Alerts */

void *test_dummy(void)
{
	return &tls_alert_recv;
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
