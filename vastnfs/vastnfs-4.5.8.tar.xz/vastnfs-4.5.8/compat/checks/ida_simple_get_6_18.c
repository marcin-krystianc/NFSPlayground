#include <linux/module.h>
#include <linux/idr.h>

/*
 * v6.18-rc1~129^2~68 "ida: remove the ida_simple_xxx() API"
 */
int test_dummy(struct ida *ida)
{
	return ida_simple_get(ida, 0, 0, GFP_KERNEL);
}

EXPORT_SYMBOL(test_dummy);
MODULE_LICENSE("GPL");
