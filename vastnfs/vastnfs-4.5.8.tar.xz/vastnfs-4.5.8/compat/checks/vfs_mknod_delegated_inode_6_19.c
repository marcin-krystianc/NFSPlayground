#include <linux/fs.h>

/*
 * v6.19-rc1~241^2~2^2~6: vfs: make vfs_mknod break delegations on parent directory
 * vfs_mknod() takes delegated_inode parameter
 */
void test(void)
{
	struct mnt_idmap *idmap = NULL;
	struct inode *dir = NULL;
	struct dentry *dentry = NULL;
	struct delegated_inode *delegated = NULL;
	vfs_mknod(idmap, dir, dentry, 0, 0, delegated);
}