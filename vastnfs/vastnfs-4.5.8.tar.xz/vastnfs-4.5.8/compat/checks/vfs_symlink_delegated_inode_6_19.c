#include <linux/fs.h>

/*
 * v6.19-rc1~241^2~2^2~5: vfs: make vfs_symlink break delegations on parent dir
 * vfs_symlink() takes delegated_inode parameter
 */
void test(void)
{
	struct mnt_idmap *idmap = NULL;
	struct inode *dir = NULL;
	struct dentry *dentry = NULL;
	const char *oldname = "";
	struct delegated_inode *delegated = NULL;
	vfs_symlink(idmap, dir, dentry, oldname, delegated);
}