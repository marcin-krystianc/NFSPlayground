#ifndef __COMPAT_NET_TLS_PROT_H__
#define __COMPAT_NET_TLS_PROT_H__

#if defined(COMPAT_DETECT_INCLUDE_NET_TLS_PROT)
#include_next <net/tls_prot.h>
#include <uapi/linux/tls.h>
#else
#include <net/tls.h>
#endif

#endif
