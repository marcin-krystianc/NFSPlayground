#ifndef __COMPAT_TLS_OFFLOAD_H__
#define __COMPAT_TLS_OFFLOAD_H__

#include_next <net/tls.h>

#ifndef COMPAT_DETECT_TLS_HANDSHAKE_ARGS_6_4
#ifndef TLS_RECORD_TYPE_ALERT
#define TLS_RECORD_TYPE_ALERT           0x15
#endif
#ifndef TLS_RECORD_TYPE_HANDSHAKE
#define TLS_RECORD_TYPE_HANDSHAKE       0x16
#endif
#ifndef TLS_RECORD_TYPE_DATA
#define TLS_RECORD_TYPE_DATA            0x17
#endif
#endif /* COMPAT_DETECT_TLS_HANDSHAKE_ARGS_6_4 */

#if !defined(COMPAT_DETECT_TLS_ALERT_RECV__EXISTS)
#define tls_get_record_type \
	compat_vastnfs_tls_get_record_type
#define tls_alert_recv \
	compat_vastnfs_tls_alert_recv

void tls_alert_recv(const struct sock *sk, const struct msghdr *msg,
		    u8 *level, u8 *description);
u8 tls_get_record_type(const struct sock *sk, const struct cmsghdr *cmsg);

#endif

#endif
