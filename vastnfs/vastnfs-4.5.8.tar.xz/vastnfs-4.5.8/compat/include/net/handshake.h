#ifndef __COMPAT_NET_HANDSHAKE_H__
#define __COMPAT_NET_HANDSHAKE_H__

#if defined(COMPAT_DETECT_TLS_HANDSHAKE_ARGS_6_4)
#include_next <net/handshake.h>
#else

enum {
	TLS_NO_KEYRING = 0,
	TLS_NO_PEERID = 0,
	TLS_NO_CERT = 0,
	TLS_NO_PRIVKEY = 0,
};

#define tls_handshake_cancel(socket) do { } while (0)
#endif

#if !defined(COMPAT_DETECT_TLS_HANDSHAKE_CLOSE__EXISTS)
#define tls_handshake_close(socket) do { } while (0)
#endif

#endif /* __COMPAT_NET_HANDSHAKE_H__ */
