#ifndef __COMPAT_LINUX_SOCK_H__
#define __COMPAT_LINUX_SOCK_H__

#include_next <net/sock.h>

#ifndef COMPAT_DETECT_TRACE_SK_DATA_READY_6_3
#define trace_sk_data_ready(sk) do {} while(0)
#endif

#endif /* __COMPAT_LINUX_SOCK_H__ */
