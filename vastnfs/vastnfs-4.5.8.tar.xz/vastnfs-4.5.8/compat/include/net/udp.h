#ifndef __COMPAT_LINUX_NET_UDP_H__
#define __COMPAT_LINUX_NET_UDP_H__

#include_next <net/udp.h>

#ifndef COMPAT_DETECT_SKB_RECV_UDP_5_19
static inline struct sk_buff *compat_skb_recv_udp(struct sock *sk, unsigned int flags, int *err)
{
	return skb_recv_udp(sk, (flags & ~MSG_DONTWAIT), (flags & MSG_DONTWAIT), err);
}
#define skb_recv_udp compat_skb_recv_udp
#endif

#endif /* __COMPAT_LINUX_NET_UDP_H__ */
