#ifndef __COMPAT_NET_GENETLINK_H__
#define __COMPAT_NET_GENETLINK_H__

#include_next <net/genetlink.h>

#if !defined(COMPAT_DETECT_GENLMSG_IPUT_6_6)

static inline void *
compat_genlmsg_iput(struct sk_buff *skb, const struct genl_info *info, struct genl_family *family)
{
       return genlmsg_put(skb, info->snd_portid, info->snd_seq, family, 0, info->genlhdr->cmd);
}

#else

static inline void *
compat_genlmsg_iput(struct sk_buff *skb, const struct genl_info *info, struct genl_family *family)
{
	(void)family;
	return genlmsg_iput(skb, info);
}

#endif

#endif
