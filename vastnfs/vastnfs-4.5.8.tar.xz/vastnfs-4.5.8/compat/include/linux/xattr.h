#ifndef __COMPAT_LINUX_XATTR_H__
#define __COMPAT_LINUX_XATTR_H__

#include_next <linux/xattr.h>

#ifndef COMPAT_DETECT_XATTR_SUPPORTS_USER_PREFIX_6_4
static inline int xattr_supports_user_prefix(struct inode *inode)
{
	return xattr_supported_namespace(inode, XATTR_USER_PREFIX);
}
#endif

#endif /* __COMPAT_LINUX_XATTR_H__ */
