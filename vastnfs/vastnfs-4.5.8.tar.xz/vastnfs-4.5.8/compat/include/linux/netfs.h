#ifndef __COMPAT_LINUX_NETFS_H__
#define __COMPAT_LINUX_NETFS_H__

#include_next <linux/netfs.h>
#include <linux/pagemap.h>

#ifndef COMPAT_DETECT_FOLIO_WAIT_FSCACHE_6_10

#define folio_test_fscache 		folio_test_private_2
#define folio_wait_fscache 		folio_wait_private_2
#define folio_wait_fscache_killable 	folio_wait_private_2_killable

#endif /* COMPAT_DETECT_FOLIO_WAIT_FSCACHE_6_10 */

#endif /* __COMPAT_LINUX_NETFS_H__ */
