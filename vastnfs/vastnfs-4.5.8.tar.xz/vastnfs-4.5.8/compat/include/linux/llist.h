#ifndef __COMPAT_LINUX_LLIST_H__
#define __COMPAT_LINUX_LLIST_H__

#include_next <linux/llist.h>

#ifndef COMPAT_DETECT_LLIST_DEL_FIRST_THIS_6_7

#define llist_del_first_this vastnfs_llist_del_first_this

extern bool llist_del_first_this(struct llist_head *head,
				 struct llist_node *this);

#endif /* COMPAT_DETECT_LLIST_DEL_FIRST_THIS_6_7 */

#endif /* __COMPAT_LINUX_LLIST_H__ */