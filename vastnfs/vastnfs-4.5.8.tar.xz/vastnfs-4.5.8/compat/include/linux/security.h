#ifndef __COMPAT_LINUX_SECURITY_H__
#define __COMPAT_LINUX_SECURITY_H__

#include_next <linux/security.h>

#if defined(COMPAT_DETECT_SECURITY_LSM_CONTEXT_6_14)

#define COMPAT_DETECT_SECURITY_LSM_CONTEXT \
				COMPAT_DETECT_SECURITY_LSM_CONTEXT_6_14
typedef struct lsm_context lsm_context_compat_t;

#elif defined(COMPAT_DETECT_SECURITY_UBUNTU_LSMCONTEXT)

#define COMPAT_DETECT_SECURITY_LSM_CONTEXT \
				COMPAT_DETECT_SECURITY_UBUNTU_LSMCONTEXT
typedef struct lsmcontext lsm_context_compat_t;

#endif

#endif /* __COMPAT_LINUX_SECURITY_H__ */
