#ifndef __LINUX_COMPAT__TRACE_POINT__
#define __LINUX_COMPAT__TRACE_POINT__

#include <linux/version.h>
#include_next <linux/tracepoint.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 10, 0)
#define __assign_str_wrap(name, data)		__assign_str(name, data)
#else
#define __assign_str_wrap(name, data)		__assign_str(name)
#endif

#ifndef __assign_str_len
#define __assign_str_len(name, data, len)	__assign_str_wrap(name, data)
#endif

#endif
