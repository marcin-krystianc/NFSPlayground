#ifndef __COMPAT_LINUX_PERCPU_COUNTER_H__
#define __COMPAT_LINUX_PERCPU_COUNTER_H__

#include_next <linux/percpu_counter.h>

#if !defined(COMPAT_DETECT_PERCPU_COUNTER_INIT_MANY_6_6)

#define __percpu_counter_init_many vastnfs_compat__percpu_counter_init_many
#define percpu_counter_destroy_many vastnfs_percpu_counter_destroy_many

int __percpu_counter_init_many(struct percpu_counter *fbc, s64 amount,
			       gfp_t gfp, u32 nr_counters,
			       struct lock_class_key *key);

void percpu_counter_destroy_many(struct percpu_counter *fbc, u32 nr_counters);

#define percpu_counter_init_many(fbc, value, gfp, nr_counters)		\
	({								\
		static struct lock_class_key __key;			\
									\
		__percpu_counter_init_many(fbc, value, gfp, nr_counters,\
					   &__key);			\
	})


#endif

#endif
