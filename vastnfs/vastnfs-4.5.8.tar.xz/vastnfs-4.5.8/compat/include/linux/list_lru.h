#ifndef __COMPAT_LINUX_LIST_LRU_H__
#define __COMPAT_LINUX_LIST_LRU_H__

#include_next <linux/list_lru.h>

#ifndef COMPAT_DETECT_LIST_LRU_ADD_OBJ_6_8
#define list_lru_add_obj list_lru_add
#endif

#ifndef COMPAT_DETECT_LIST_LRU_DEL_OBJ_6_8
#define list_lru_del_obj list_lru_del
#endif

#endif /* __COMPAT_LINUX_LIST_LRU_H__ */
