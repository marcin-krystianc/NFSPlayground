#ifndef __COMPAT_LINUX_STRING_H__
#define __COMPAT_LINUX_STRING_H__

#include_next <linux/string.h>

#ifndef COMPAT_DETECT_STR_FALSE_TRUE_6_12
static inline const char *str_false_true(bool v)
{
	return v ? "true" : "false";
}
#endif /* COMPAT_DETECT_STR_FALSE_TRUE_6_12 */

#endif /* __COMPAT_LINUX_STRING_H__ */