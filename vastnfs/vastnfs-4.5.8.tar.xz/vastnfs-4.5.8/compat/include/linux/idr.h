#ifndef __COMPAT_LINUX_IDR_H__
#define __COMPAT_LINUX_IDR_H__

#include_next <linux/idr.h>

#ifndef COMPAT_DETECT_IDA_SIMPLE_GET_6_18
#define ida_simple_get(ida, start, end, gfp)	\
			ida_alloc_range(ida, start, (end) - 1, gfp)
#define ida_simple_remove(ida, id)	ida_free(ida, id)
#endif /* COMPAT_DETECT_IDA_SIMPLE_GET_6_18 */

#endif /* __COMPAT_LINUX_IDR_H__ */
