#ifndef __COMPAT_LINUX_FS_H__
#define __COMPAT_LINUX_FS_H__

#include_next <linux/fs.h>

#ifndef SLAB_MEM_SPREAD
#define SLAB_MEM_SPREAD	((slab_flags_t __force)0)
#endif

#if defined(COMPAT_DETECT_INCLUDE_LINUX_FILELOCK)
#include <linux/filelock.h>
#endif

#if defined(COMPAT_DETECT_GENERIC_FILLATTR_6_6)
#define COMPAT_FILLATTR(request_mask) request_mask,
#else
#define COMPAT_FILLATTR(request_mask)
#endif

#if !defined(COMPAT_DETECT_INODE_GET_CTIME_6_6)
/**
 * inode_set_ctime_to_ts - set the ctime in the inode
 * @inode: inode in which to set the ctime
 * @ts: value to set in the ctime field
 *
 * Set the ctime in @inode to @ts
 */
static inline struct timespec64 inode_set_ctime_to_ts(struct inode *inode,
						      struct timespec64 ts)
{
	inode->i_ctime = ts;
	return ts;
}

/**
 * inode_set_ctime - set the ctime in the inode
 * @inode: inode in which to set the ctime
 * @sec: tv_sec value to set
 * @nsec: tv_nsec value to set
 *
 * Set the ctime in @inode to { @sec, @nsec }
 */
static inline struct timespec64 inode_set_ctime(struct inode *inode,
						time64_t sec, long nsec)
{
	struct timespec64 ts = { .tv_sec  = sec, .tv_nsec = nsec };

	return inode_set_ctime_to_ts(inode, ts);
}

static inline long inode_get_ctime_nsec(const struct inode *inode)
{
	return inode->i_ctime.tv_nsec;
}

static inline struct timespec64 inode_get_ctime(const struct inode *inode)
{
	return inode->i_ctime;
}

static inline struct timespec64 inode_set_ctime_current(struct inode *inode)
{
	struct timespec64 now = current_time(inode);

	inode_set_ctime(inode, now.tv_sec, now.tv_nsec);
	return now;
}

#endif /* COMPAT_DETECT_INODE_GET_CTIME_6_6 */

#if !defined(COMPAT_DETECT_INODE_GET_ATIME_6_7)
static inline time64_t inode_get_ctime_sec(const struct inode *inode)
{
#if !defined(COMPAT_DETECT_INODE_GET_CTIME_6_6)
	return inode->i_ctime.tv_sec;
#else
	return inode_get_ctime(inode).tv_sec;
#endif
}

static inline struct timespec64 inode_set_mtime_to_ts(struct inode *inode,
						      struct timespec64 ts)
{
	inode->i_mtime = ts;
	return ts;
}

static inline struct timespec64 inode_set_mtime(struct inode *inode,
						time64_t sec, long nsec)
{
	struct timespec64 ts = { .tv_sec  = sec, .tv_nsec = nsec };

	return inode_set_mtime_to_ts(inode, ts);
}

static inline time64_t inode_get_mtime_sec(const struct inode *inode)
{
	return inode->i_mtime.tv_sec;
}

static inline long inode_get_mtime_nsec(const struct inode *inode)
{
	return inode->i_mtime.tv_nsec;
}

static inline struct timespec64 inode_get_mtime(const struct inode *inode)
{
	return inode->i_mtime;
}

static inline time64_t inode_get_atime_sec(const struct inode *inode)
{
	return inode->i_atime.tv_sec;
}

static inline long inode_get_atime_nsec(const struct inode *inode)
{
	return inode->i_atime.tv_nsec;
}

static inline struct timespec64 inode_get_atime(const struct inode *inode)
{
	return inode->i_atime;
}

static inline struct timespec64 inode_set_atime_to_ts(struct inode *inode,
						      struct timespec64 ts)
{
	inode->i_atime = ts;
	return ts;
}

static inline struct timespec64 inode_set_atime(struct inode *inode,
						time64_t sec, long nsec)
{
	struct timespec64 ts = { .tv_sec  = sec, .tv_nsec = nsec };

	return inode_set_atime_to_ts(inode, ts);
}

static inline struct timespec64 simple_inode_init_ts(struct inode *inode)
{
	struct timespec64 ts = inode_set_ctime_current(inode);

	inode_set_atime_to_ts(inode, ts);
	inode_set_mtime_to_ts(inode, ts);
	return ts;
}

#endif /* COMPAT_DETECT_INODE_GET_ATIME_6_7 */

#ifndef COMPAT_DETECT_INODE_UPDATE_TIMESTAMPS_6_6
int inode_update_timestamps(struct inode *inode, int flags);
#endif

#ifdef COMPAT_DETECT_FILE_TIME_FLAGS_7_0
/*
 * This was removed in the newer kernel in havor of newer lib code, but we are
 * still using it in our compat lib code.
 */
enum file_time_flags {
       S_ATIME = 1,
       S_MTIME = 2,
       S_CTIME = 4,
       S_VERSION = 8,
};
#endif

#ifdef COMPAT_DETECT_GENERIC_PERMISSION_MNT_IDMAP_6_3
#define COMPAT_STRUCT_MNT_IDMAP	struct mnt_idmap
#define COMPAT_NOP_MNT_IDMAP	nop_mnt_idmap
#else /* !COMPAT_DETECT_GENERIC_PERMISSION_MNT_IDMAP_6_3 */
#define COMPAT_STRUCT_MNT_IDMAP	struct user_namespace
#define COMPAT_NOP_MNT_IDMAP	init_user_ns
#endif /* COMPAT_DETECT_GENERIC_PERMISSION_MNT_IDMAP_6_3 */

#if defined(COMPAT_DETECT_STRUCT_FILE_LOCK_CORE_6_9)
#define COMPAT_DETECT_SET_LEASE_INT_PARAM_6_6
#endif

#if defined(COMPAT_DETECT_SET_LEASE_INT_PARAM_6_6)
#define FS_SETLEASE_ARG_TYPE int
#else
#define FS_SETLEASE_ARG_TYPE long
#endif

#if defined(COMPAT_DETECT_FILLDIR_T_RET_BOOL_6_1)
#define FILLDIR_T_RET_TYPE bool
#else
#define FILLDIR_T_RET_TYPE int
#endif

#ifndef COMPAT_DETECT_SETATTR_SHOULD_DROP_SGID_6_2
static inline int setattr_should_drop_sgid(COMPAT_STRUCT_MNT_IDMAP *idmap,
						const struct inode *inode)
{
	mode_t mode = inode->i_mode;
	if (!(mode & S_ISGID))
		return 0;
	if (mode & S_IXGRP)
		return ATTR_KILL_SGID;
	if ((mode & (S_ISGID | S_IXGRP)) == (S_ISGID | S_IXGRP))
		return ATTR_KILL_SGID;
	return 0;
}
#endif

static inline spinlock_t* compat_address_space_private_lock(struct address_space* mapping)
{
#ifdef COMPAT_DETECT_ADDRESS_SPACE_I_PRIVATE
	return &mapping->i_private_lock;
#else
	return &mapping->private_lock;
#endif
}

#if !defined(COMPAT_DETECT_WRITE_USES_FOLIO_6_12) && !defined(COMPAT_DETECT_WRITE_BEGIN_KIOCB_6_17)
extern ssize_t vnfs_generic_perform_write(struct kiocb *, struct iov_iter *);
#define generic_perform_write vnfs_generic_perform_write
#endif /* COMPAT_DETECT_WRITE_USES_FOLIO_6_12 */

#ifndef COMPAT_DETECT_FOLIO_SET_ERROR_6_12
static inline void folio_set_error(struct folio *folio) { /* empty */ }
#endif /* COMPAT_DETECT_WRITE_USES_FOLIO_6_12 */

#ifdef COMPAT_DETECT_VFS_MKDIR_DELEGATED_INODE_6_19
static inline int compat_vfs_mkdir(COMPAT_STRUCT_MNT_IDMAP *idmap,
				   struct inode *dir, struct dentry *dentry,
				   umode_t mode)
{
	struct delegated_inode *delegated = NULL;
	struct dentry *result = vfs_mkdir(idmap, dir, dentry, mode, delegated);
	return PTR_ERR_OR_ZERO(result);
}
#define vfs_mkdir compat_vfs_mkdir
#elif defined(COMPAT_DETECT_VFS_MKDIR_RETURNS_DENTRY_6_15)
static inline int compat_vfs_mkdir(COMPAT_STRUCT_MNT_IDMAP *idmap,
				   struct inode *dir, struct dentry *dentry,
				   umode_t mode)
{
	struct dentry *result = vfs_mkdir(idmap, dir, dentry, mode);
	return PTR_ERR_OR_ZERO(result);
}
#define vfs_mkdir compat_vfs_mkdir
#endif /* COMPAT_DETECT_VFS_MKDIR_RETURNS_DENTRY_6_15 */

#ifndef no_llseek
#define no_llseek NULL
#endif

#ifndef COMPAT_DETECT_SB_I_NOUMASK_6_7
#define SB_I_NOUMASK	0x00001000
#endif

#if defined(COMPAT_DETECT_SUPERBLOCK_XATTR_CONST_6_7)
#define SUPERBLOCK_XATTR_CONST const
#else
#define SUPERBLOCK_XATTR_CONST
#endif

#ifndef COMPAT_DETECT_GENERIC_DROP_INODE_6_18
#define generic_drop_inode inode_generic_drop
#endif /* COMPAT_DETECT_GENERIC_DROP_INODE_6_18 */


/* Linux 6.19+ compatibility fixes for inode state and networking */

/* Handle inode_state_flags struct vs unsigned long */
static inline bool compat_inode_state_check(struct inode *inode, unsigned long mask)
{
#ifdef COMPAT_DETECT_INODE_STATE_STRUCT_6_19
	return (inode->i_state.__state & mask) != 0;
#else
	return (inode->i_state & mask) != 0;
#endif
}

static inline unsigned long compat_inode_state_get_raw(struct inode *inode)
{
#ifdef COMPAT_DETECT_INODE_STATE_STRUCT_6_19
	return (unsigned long)inode->i_state.__state;
#else
	return (unsigned long)inode->i_state;
#endif
}

/* VFS function compatibility wrappers for 6.19+ delegated_inode changes */

#ifdef COMPAT_DETECT_VFS_CREATE_DELEGATED_INODE_6_19
static inline int compat_vfs_create(COMPAT_STRUCT_MNT_IDMAP *idmap, struct inode *dir, struct dentry *dentry, umode_t mode, bool want_excl)
{
	struct delegated_inode *delegated = NULL;
	return vfs_create(idmap, dentry, mode, delegated);
}
#define vfs_create compat_vfs_create
#endif

#ifdef COMPAT_DETECT_VFS_SYMLINK_DELEGATED_INODE_6_19
static inline int compat_vfs_symlink(COMPAT_STRUCT_MNT_IDMAP *idmap, struct inode *dir, struct dentry *dentry, const char *oldname)
{
	struct delegated_inode *delegated = NULL;
	return vfs_symlink(idmap, dir, dentry, oldname, delegated);
}
#define vfs_symlink compat_vfs_symlink
#endif

#ifdef COMPAT_DETECT_VFS_UNLINK_DELEGATED_INODE_6_19
static inline int compat_vfs_unlink(COMPAT_STRUCT_MNT_IDMAP *idmap, struct inode *dir, struct dentry *dentry, struct inode **delegated_inode)
{
	struct delegated_inode *delegated = NULL;
	return vfs_unlink(idmap, dir, dentry, delegated);
}
#define vfs_unlink compat_vfs_unlink
#endif

#ifdef COMPAT_DETECT_VFS_RMDIR_DELEGATED_INODE_6_19
static inline int compat_vfs_rmdir(COMPAT_STRUCT_MNT_IDMAP *idmap, struct inode *dir, struct dentry *dentry)
{
	struct delegated_inode *delegated = NULL;
	return vfs_rmdir(idmap, dir, dentry, delegated);
}
#define vfs_rmdir compat_vfs_rmdir
#endif

#ifdef COMPAT_DETECT_VFS_LINK_DELEGATED_INODE_6_19
static inline int compat_vfs_link(struct dentry *old_dentry, COMPAT_STRUCT_MNT_IDMAP *idmap, struct inode *dir, struct dentry *new_dentry, struct inode **delegated_inode)
{
	struct delegated_inode *delegated = NULL;
	return vfs_link(old_dentry, idmap, dir, new_dentry, delegated);
}
#define vfs_link compat_vfs_link
#endif

#ifdef COMPAT_DETECT_VFS_MKNOD_DELEGATED_INODE_6_19
static inline int compat_vfs_mknod(COMPAT_STRUCT_MNT_IDMAP *idmap, struct inode *dir, struct dentry *dentry, umode_t mode, dev_t rdev)
{
	struct delegated_inode *delegated = NULL;
	return vfs_mknod(idmap, dir, dentry, mode, rdev, delegated);
}
#define vfs_mknod compat_vfs_mknod
#endif

#endif /* __COMPAT_LINUX_FS_H__ */
