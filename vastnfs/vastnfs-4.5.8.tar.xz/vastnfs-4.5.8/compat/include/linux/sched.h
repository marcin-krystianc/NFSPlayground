#ifndef __COMPAT_LINUX_SCHED_H__
#define __COMPAT_LINUX_SCHED_H__

#include_next <linux/sched.h>

#if !defined(COMPAT_DETECT_TASK_FREEZABLE_6_1)

#define TASK_FREEZABLE 0
#define TASK_FREEZABLE_UNSAFE 0

#endif /* ! COMPAT_DETECT_TASK_FREEZABLE_6_1 */

#endif
