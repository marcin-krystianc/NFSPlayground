#ifndef __COMPAT_LINUX_SLAB_H__
#define __COMPAT_LINUX_SLAB_H__

#include_next <linux/slab.h>

#ifndef COMPAT_DETECT_KMEMDUP_NOPROF_6_10
/* 
 * For kernels without memory profiling, map _noprof functions 
 * to their regular equivalents 
 */
#define kmemdup_noprof(p, len, flags) kmemdup(p, len, flags)
#endif

#ifndef COMPAT_DETECT_ALLOC_HOOKS_6_10
/*
 * For kernels without memory profiling hooks, 
 * alloc_hooks is a no-op passthrough
 */
#define alloc_hooks(x) (x)
#endif

#endif /* __COMPAT_LINUX_SLAB_H__ */