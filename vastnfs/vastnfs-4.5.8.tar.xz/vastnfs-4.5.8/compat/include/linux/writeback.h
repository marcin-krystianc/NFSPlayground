#ifndef __COMPAT_LINUX_WRITEBACK_H__
#define __COMPAT_LINUX_WRITEBACK_H__

#include_next <linux/writeback.h>

#ifndef COMPAT_DETECT_WRITE_CACHE_PAGES_6_18
/*
 * v6.18-rc1~130^2~246 "mm: remove write_cache_pages"
 * Provide writepage_t and write_cache_pages using writeback_iter.
 */
typedef int (*writepage_t)(struct folio *folio, struct writeback_control *wbc,
			   void *data);

extern int write_cache_pages(struct address_space *mapping,
			     struct writeback_control *wbc,
			     writepage_t writepage, void *data);
#endif /* COMPAT_DETECT_WRITE_CACHE_PAGES_6_18 */

#endif /* __COMPAT_LINUX_WRITEBACK_H__ */
