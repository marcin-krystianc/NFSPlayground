#ifndef __COMPAT_LINUX_NSPROXY_H__
#define __COMPAT_LINUX_NSPROXY_H__

#include_next <linux/nsproxy.h>

#if defined(COMPAT_DETECT_NS_COMMON_FOR_NAMESPACE_TAGS_7_0)
#define NS_COMMON_RETVAL       struct ns_common
#define to_ns_common_compat(x) to_ns_common(x)
#else
#define NS_COMMON_RETVAL       void
#define to_ns_common_compat(x) x
#endif

#endif /* __COMPAT_LINUX_NSPROXY_H__ */
