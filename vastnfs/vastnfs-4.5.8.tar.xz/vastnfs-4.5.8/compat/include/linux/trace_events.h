#ifndef __LINUX_COMPAT__TRACE_EVENTS__
#define __LINUX_COMPAT__TRACE_EVENTS__

#include_next <linux/trace_events.h>

#define EVENT_NULL_STR          "(null)"

#endif
