#ifndef __COMPAT_LINUX_GFP_H__
#define __COMPAT_LINUX_GFP_H__

#include_next <linux/gfp.h>

#ifndef COMPAT_DETECT_ALLOC_PAGES_BULK_ARRAY_NODE_6_14

static inline unsigned long alloc_pages_bulk_array(gfp_t gfp, int nr_pages,
						struct page **page_array)
{
	return alloc_pages_bulk(gfp, nr_pages, page_array);
}

static inline unsigned long alloc_pages_bulk_array_node(gfp_t gfp, int nid,
			unsigned long nr_pages, struct page **page_array)
{
	return alloc_pages_bulk_node(gfp, nid, nr_pages, page_array);
}

#endif /* COMPAT_DETECT_ALLOC_PAGES_BULK_ARRAY_NODE_6_14 */

#endif /* __COMPAT_LINUX_GFP_H__ */
