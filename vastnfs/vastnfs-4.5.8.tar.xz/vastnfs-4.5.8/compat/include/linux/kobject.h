#ifndef __COMPAT_LINUX_KOBJECT_H__
#define __COMPAT_LINUX_KOBJECT_H__

#include_next <linux/kobject.h>

#ifdef COMPAT_DETECT_KOBJECT_GET_OWNERSHIP_6_2
#define CONST_STRUCT_KOBJECT const struct kobject
#else
#define CONST_STRUCT_KOBJECT struct kobject
#endif

#endif /* __COMPAT_LINUX_KOBJECT_H__ */
