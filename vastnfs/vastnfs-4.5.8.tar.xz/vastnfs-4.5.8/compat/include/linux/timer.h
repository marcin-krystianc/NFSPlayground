#ifndef __COMPAT_LINUX_TIMER_H__
#define __COMPAT_LINUX_TIMER_H__

#include_next <linux/timer.h>

#ifdef COMPAT_DETECT_TIMER_DELETE_SYNC_6_15
#define del_timer_sync timer_delete_sync
#endif /* COMPAT_DETECT_TIMER_DELETE_SYNC_6_15 */

#ifndef COMPAT_DETECT_FROM_TIMER_6_16
#define from_timer(var, callback_timer, timer_fieldname) \
	container_of(callback_timer, typeof(*var), timer_fieldname)
#endif /* COMPAT_DETECT_FROM_TIMER_6_16 */

#endif /* __COMPAT_LINUX_TIMER_H__ */
