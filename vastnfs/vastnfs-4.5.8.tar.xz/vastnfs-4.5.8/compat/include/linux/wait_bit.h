#ifndef __COMPAT_LINUX_WAIT_BIT_H__
#define __COMPAT_LINUX_WAIT_BIT_H__

#include_next <linux/wait_bit.h>

#if !defined(COMPAT_DETECT_STORE_RELEASE_WAKE_UP_6_13)
#define store_release_wake_up(var, val)                                              \
do {                                                                         \
       smp_store_release(var, val);                                          \
       smp_mb();                                                             \
       wake_up_var(var);                                                     \
} while (0)
#endif

#endif /* __COMPAT_LINUX_WAIT_BIT_H__ */
