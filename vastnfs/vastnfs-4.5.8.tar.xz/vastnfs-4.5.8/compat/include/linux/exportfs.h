#ifndef __COMPAT_LINUX_EXPORTFS_H__
#define __COMPAT_LINUX_EXPORTFS_H__

#include_next <linux/exportfs.h>

#ifndef COMPAT_DETECT_EXPORT_OP_FLUSH_ON_CLOSE_6_4
#define EXPORT_OP_FLUSH_ON_CLOSE 0
#endif

#ifndef COMPAT_DETECT_EXPORTFS_LOCK_OP_IS_ASYNC_6_7
static inline bool
opt_exportfs_lock_op_is_async(const struct export_operations *export_ops)
{
	return false;
}
#else
static inline bool
opt_exportfs_lock_op_is_async(const struct export_operations *export_ops)
{
	return exportfs_lock_op_is_async(export_ops);
}
#endif

#ifndef COMPAT_DETECT_EXPORTFS_CAN_DECODE_FH_6_7
static inline bool exportfs_can_decode_fh(const struct export_operations *nop)
{
	return nop && nop->fh_to_dentry;
}
#endif

#endif /* __COMPAT_LINUX_EXPORTFS_H__ */
