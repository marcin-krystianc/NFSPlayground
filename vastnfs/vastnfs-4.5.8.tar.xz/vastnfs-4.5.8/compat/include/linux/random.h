#ifndef __COMPAT_LINUX_RANDOM_H__
#define __COMPAT_LINUX_RANDOM_H__

#include_next <linux/random.h>

#ifndef COMPAT_DETECT_GET_RANDOM_U32_BELOW_6_2
static inline u32 get_random_u32_below(u32 ceil)
{
	return prandom_u32() % ceil;
}
#endif

#endif /* __COMPAT_LINUX_RANDOM_H__ */
