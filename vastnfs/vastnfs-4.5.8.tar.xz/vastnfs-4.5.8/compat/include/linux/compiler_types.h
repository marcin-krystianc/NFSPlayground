#ifndef __COMPAT_LINUX_COMPILERT_TYPES_H__
#define __COMPAT_LINUX_COMPILERT_TYPES_H__

#include_next <linux/compiler_types.h>

#ifndef __counted_by
#define __counted_by(member)
#endif

#endif

