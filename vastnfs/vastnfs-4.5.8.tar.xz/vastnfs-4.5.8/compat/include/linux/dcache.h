#ifndef __COMPAT_LINUX_DCACHE_H__
#define __COMPAT_LINUX_DCACHE_H__

#include_next <linux/dcache.h>

#ifndef QSTR
#define QSTR(n) (struct qstr)QSTR_INIT(n, strlen(n))
#endif

#ifndef COMPAT_DETECT_D_HASH_AND_LOOKUP_6_16
extern struct dentry *d_hash_and_lookup(struct dentry *dir, struct qstr *name);
#endif /* COMPAT_DETECT_D_HASH_AND_LOOKUP_6_16 */

#ifndef COMPAT_DETECT_SET_DEFAULT_D_OP_6_17
#define set_default_d_op(sb, ops) sb->s_d_op = ops
#endif

#ifndef COMPAT_DETECT_D_MAKE_PERSISTENT_6_19
static inline void d_make_persistent(struct dentry *dentry, struct inode *inode)
{
	d_instantiate(dentry, inode);
	dget(dentry); /* Make it persistent */
}
#endif /* COMPAT_DETECT_D_MAKE_PERSISTENT_6_19 */

#endif /* __COMPAT_LINUX_DCACHE_H__ */
