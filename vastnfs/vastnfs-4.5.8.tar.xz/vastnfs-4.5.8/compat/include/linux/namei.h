#ifndef __COMPAT_LINUX_NAMEI_H__
#define __COMPAT_LINUX_NAMEI_H__

#include_next <linux/namei.h>

#ifndef COMPAT_DETECT_LOOKUP_ONE_LEN_UNLOCKED_6_16
extern struct dentry *lookup_one_len_unlocked(const char *name,
					      struct dentry *base,
					      int len);
#endif /* COMPAT_DETECT_LOOKUP_ONE_LEN_UNLOCKED_6_16 */

#ifndef COMPAT_DETECT_LOOKUP_ONE_LEN_6_16
extern struct dentry *lookup_one_len(const char *name,
				     struct dentry *base, int len);
#endif /* COMPAT_DETECT_LOOKUP_ONE_LEN_6_16 */

#ifndef COMPAT_DETECT_LOOKUP_POSITIVE_UNLOCKED_6_16
extern struct dentry *lookup_positive_unlocked(const char *name,
					       struct dentry *base,
					       int len);
#endif /* COMPAT_DETECT_LOOKUP_POSITIVE_UNLOCKED_6_16 */

#ifndef COMPAT_DETECT_TRY_LOOKUP_NOPERM_6_17
static inline struct dentry *try_lookup_noperm(struct qstr *name, struct dentry *base)
{
	return lookup_one_len_unlocked(name->name, base, name->len);
}
#endif /* COMPAT_DETECT_TRY_LOOKUP_NOPERM_6_17 */

#ifndef COMPAT_DETECT_SIMPLE_DONE_CREATING_6_19

#ifdef COMPAT_DETECT_SIMPLE_START_CREATING_6_19
// For v6.17 to 6.18 use the 6.19 version of simple_start_creating
#define simple_start_creating simple_start_creating_6_19

#endif

extern int lookup_noperm_common_6_19(struct qstr *qname, struct dentry *base);
extern struct dentry *start_dirop_6_19(struct dentry *parent, struct qstr *name,
				       unsigned int lookup_flags);


static inline struct dentry *simple_start_creating(struct dentry *parent, const char *name)
{
	struct qstr qname = QSTR(name);
	int err;

	err = lookup_noperm_common_6_19(&qname, parent);
	if (err)
		return ERR_PTR(err);
	return start_dirop_6_19(parent, &qname, LOOKUP_CREATE | LOOKUP_EXCL);
}

static inline void simple_done_creating(struct dentry *child)
{
	inode_unlock(child->d_parent->d_inode);
	dput(child);
}
#endif /* COMPAT_DETECT_SIMPLE_DONE_CREATING_6_19 */

#endif /* __COMPAT_LINUX_NAMEI_H__ */
