#ifndef __COMPAT_LINUX_UNALIGNED_H__
#define __COMPAT_LINUX_UNALIGNED_H__

#ifdef COMPAT_DETECT_INCLUDE_LINUX_UNALIGNED_6_12
#include_next <linux/unaligned.h>
#else
#include <asm/unaligned.h>
#endif

#endif /* __COMPAT_LINUX_UNALIGNED_H__ */
