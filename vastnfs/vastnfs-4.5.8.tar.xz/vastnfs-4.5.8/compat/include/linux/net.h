#ifndef __COMPAT_LINUX_NET_H__
#define __COMPAT_LINUX_NET_H__

#include_next <linux/net.h>

/* Linux 6.19+ changed kernel_bind and kernel_connect to use sockaddr_unsized */
#ifdef COMPAT_DETECT_KERNEL_BIND_SOCKADDR_UNSIZED_6_19
static inline int compat_kernel_bind(struct socket *sock, struct sockaddr *addr, int addrlen)
{
	return kernel_bind(sock, (struct sockaddr_unsized *)addr, addrlen);
}
#else
static inline int compat_kernel_bind(struct socket *sock, struct sockaddr *addr, int addrlen)
{
	return kernel_bind(sock, addr, addrlen);
}
#endif
#define kernel_bind compat_kernel_bind

#ifdef COMPAT_DETECT_KERNEL_CONNECT_SOCKADDR_UNSIZED_6_19
static inline int compat_kernel_connect(struct socket *sock, struct sockaddr *addr, int addrlen, int flags)
{
	return kernel_connect(sock, (struct sockaddr_unsized *)addr, addrlen, flags);
}
#else
static inline int compat_kernel_connect(struct socket *sock, struct sockaddr *addr, int addrlen, int flags)
{
	return kernel_connect(sock, addr, addrlen, flags);
}
#endif
#define kernel_connect compat_kernel_connect

#endif /* __COMPAT_LINUX_NET_H__ */