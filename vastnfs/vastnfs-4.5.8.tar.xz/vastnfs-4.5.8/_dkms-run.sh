#!/bin/bash

make "$@"
