// SPDX-License-Identifier: GPL-2.0
/*
 * linux/net/sunrpc/jobid.h
 *
 * Job ID handling for RPC authentication
 */

#ifndef _SUNRPC_JOBID_H
#define _SUNRPC_JOBID_H

#include <linux/sunrpc/sched.h>
#include <linux/sunrpc/xdr.h>
#include <linux/seq_file.h>

int jobid_init(void);
void jobid_destroy(void);

char *alloc_jobid_buffer(void);
int marshal_nodename_and_job_id(struct rpc_task *task, struct xdr_stream *xdr);

void env_cache_flush(void);
void jobid_cache_print_stats(struct seq_file *m);
void jobid_cache_print_dump(struct seq_file *m);

#endif /* _SUNRPC_JOBID_H */
