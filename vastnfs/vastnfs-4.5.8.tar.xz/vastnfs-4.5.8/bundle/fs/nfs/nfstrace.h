/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2013 Trond Myklebust <Trond.Myklebust@netapp.com>
 */
#undef TRACE_SYSTEM
#define TRACE_SYSTEM nfs

#if !defined(_TRACE_NFS_H) || defined(TRACE_HEADER_MULTI_READ)
#define _TRACE_NFS_H

#include <linux/tracepoint.h>
#include <linux/iversion.h>
#include <linux/nfs_fs_sb.h>
#include "internal.h"

#include <trace/misc/fs.h>
#include <trace/misc/nfs.h>
#include <trace/misc/sunrpc.h>

#define nfs_show_cache_validity(v) \
	__print_flags(v, "|", \
			{ NFS_INO_INVALID_DATA, "INVALID_DATA" }, \
			{ NFS_INO_INVALID_ATIME, "INVALID_ATIME" }, \
			{ NFS_INO_INVALID_ACCESS, "INVALID_ACCESS" }, \
			{ NFS_INO_INVALID_ACL, "INVALID_ACL" }, \
			{ NFS_INO_REVAL_FORCED, "REVAL_FORCED" }, \
			{ NFS_INO_INVALID_LABEL, "INVALID_LABEL" }, \
			{ NFS_INO_INVALID_CHANGE, "INVALID_CHANGE" }, \
			{ NFS_INO_INVALID_CTIME, "INVALID_CTIME" }, \
			{ NFS_INO_INVALID_MTIME, "INVALID_MTIME" }, \
			{ NFS_INO_INVALID_SIZE, "INVALID_SIZE" }, \
			{ NFS_INO_INVALID_OTHER, "INVALID_OTHER" }, \
			{ NFS_INO_DATA_INVAL_DEFER, "DATA_INVAL_DEFER" }, \
			{ NFS_INO_INVALID_BLOCKS, "INVALID_BLOCKS" }, \
			{ NFS_INO_INVALID_XATTR, "INVALID_XATTR" }, \
			{ NFS_INO_INVALID_NLINK, "INVALID_NLINK" }, \
			{ NFS_INO_INVALID_MODE, "INVALID_MODE" })

#define nfs_show_nfsi_flags(v) \
	__print_flags(v, "|", \
			{ BIT(NFS_INO_STALE), "STALE" }, \
			{ BIT(NFS_INO_ACL_LRU_SET), "ACL_LRU_SET" }, \
			{ BIT(NFS_INO_INVALIDATING), "INVALIDATING" }, \
			{ BIT(NFS_INO_LAYOUTCOMMIT), "NEED_LAYOUTCOMMIT" }, \
			{ BIT(NFS_INO_LAYOUTCOMMITTING), "LAYOUTCOMMIT" }, \
			{ BIT(NFS_INO_LAYOUTSTATS), "LAYOUTSTATS" }, \
			{ BIT(NFS_INO_ODIRECT), "ODIRECT" })

#define nfs_show_dname(dentry) \
	((IS_ERR_OR_NULL(dentry) || dentry->d_name.len <= 0) ? "" \
				: (const char*)dentry->d_name.name)

DECLARE_EVENT_CLASS(nfs_file_event,
		TP_PROTO(
			const struct kiocb *iocb,
			const struct iov_iter *iter
		),

		TP_ARGS(iocb, iter),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, nfssrv_trid)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(u32, count)
		),

		TP_fast_assign(
			const struct inode *inode = iocb->ki_filp->f_inode;
			const struct nfs_server *server = NFS_SERVER(inode);
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->fileid = nfsi->fileid;
			__entry->offset = iocb->ki_pos;
			__entry->count = iov_iter_count(iter);
		),

		TP_printk(
			"fileid=%02x:%02x:%llu nfssrv_trid:%u"
			" fhandle=0x%08x offset=%lld count=%u",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->nfssrv_trid, __entry->fhandle,
			__entry->offset, __entry->count
		)
);

#define DEFINE_NFS_FILE_EVENT(name) \
	DEFINE_EVENT(nfs_file_event, name, \
			TP_PROTO( \
				const struct kiocb *iocb, \
				const struct iov_iter *iter \
			), \
			TP_ARGS(iocb, iter))

DEFINE_NFS_FILE_EVENT(nfs_file_read);
DEFINE_NFS_FILE_EVENT(nfs_file_write);

DECLARE_EVENT_CLASS(nfs_inode_event,
		TP_PROTO(
			const struct inode *inode
		),

		TP_ARGS(inode),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, nfssrv_trid)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob, NFS_I(inode)->fh.size)
			__field(u32, server_idx1)
			__field(u64, fileid)
			__field(u64, version)
			__field(unsigned long, nfsi_flags)
			__field(unsigned long, cache_validity)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);
			struct nfs_server *server = NFS_SERVER(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->fhandle_size = nfsi->fh.size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &nfsi->fh.data[0],
			       __entry->fhandle_size);
			__entry->server_idx1 = nfsi->server_idx1;
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->nfsi_flags = nfsi->flags;
			__entry->cache_validity = nfsi->cache_validity;
		),

		TP_printk(
			"nfssrv_trid=%d fileid=%02x:%02x:%llu fhandle=0x%08x "
			"%s server_idx1=%d version=%llu nfsi_flags=0x%lx "
			"cache_validity=0x%lx", __entry->nfssrv_trid,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid, __entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				__entry->fhandle_size, 1), __entry->server_idx1,
			(unsigned long long)__entry->version,
			__entry->nfsi_flags, __entry->cache_validity
		)
);

DECLARE_EVENT_CLASS(nfs_inode_event_done,
		TP_PROTO(
			const struct inode *inode,
			int error
		),

		TP_ARGS(inode, error),

		TP_STRUCT__entry(
			__field(unsigned int, error)
			__field(dev_t, dev)
			__field(u32, nfssrv_trid)
			__field(u32, server_idx1)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob, NFS_I(inode)->fh.size)
			__field(unsigned char, type)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, size)
			__field(unsigned long, nfsi_flags)
			__field(unsigned long, cache_validity)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);
			struct nfs_server *server = NFS_SERVER(inode);

			__entry->error = error < 0 ? -error : 0;
			__entry->dev = inode->i_sb->s_dev;
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__entry->server_idx1 = nfsi->server_idx1;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->fhandle_size = nfsi->fh.size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &nfsi->fh.data[0],
			       __entry->fhandle_size);
			__entry->type = nfs_umode_to_dtype(inode->i_mode);
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->size = i_size_read(inode);
			__entry->nfsi_flags = nfsi->flags;
			__entry->cache_validity = nfsi->cache_validity;
		),

		TP_printk(
			"error=%u (%s) nfssrv_trid=%d fileid=%02x:%02x:%llu "
			"fhandle=0x%08x %s server_idx1=%d type=%u (%s) "
			"version=%llu size=%lld cache_validity=0x%lx (%s) "
			"nfs_flags=0x%lx (%s)", -__entry->error,
			show_nfs_status(__entry->error), __entry->nfssrv_trid,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1),
			__entry->server_idx1, __entry->type,
			show_fs_dirent_type(__entry->type),
			(unsigned long long)__entry->version,
			(long long)__entry->size,
			__entry->cache_validity,
			nfs_show_cache_validity(__entry->cache_validity),
			__entry->nfsi_flags,
			nfs_show_nfsi_flags(__entry->nfsi_flags)
		)
);

#define DEFINE_NFS_INODE_EVENT(name) \
	DEFINE_EVENT(nfs_inode_event, name, \
			TP_PROTO( \
				const struct inode *inode \
			), \
			TP_ARGS(inode))
#define DEFINE_NFS_INODE_EVENT_DONE(name) \
	DEFINE_EVENT(nfs_inode_event_done, name, \
			TP_PROTO( \
				const struct inode *inode, \
				int error \
			), \
			TP_ARGS(inode, error))
DEFINE_NFS_INODE_EVENT(nfs_set_inode_stale);
DEFINE_NFS_INODE_EVENT(nfs_refresh_inode_enter);
DEFINE_NFS_INODE_EVENT(nfs_inode_bind_server_idx);
DEFINE_NFS_INODE_EVENT_DONE(nfs_refresh_inode_exit);
DEFINE_NFS_INODE_EVENT(nfs_revalidate_inode_enter);
DEFINE_NFS_INODE_EVENT_DONE(nfs_revalidate_inode_exit);
DEFINE_NFS_INODE_EVENT(nfs_invalidate_mapping_enter);
DEFINE_NFS_INODE_EVENT_DONE(nfs_invalidate_mapping_exit);
DEFINE_NFS_INODE_EVENT(nfs_getattr_enter);
DEFINE_NFS_INODE_EVENT_DONE(nfs_getattr_exit);
DEFINE_NFS_INODE_EVENT(nfs_statfs_enter);
DEFINE_NFS_INODE_EVENT_DONE(nfs_statfs_exit);
DEFINE_NFS_INODE_EVENT(nfs_setattr_enter);
DEFINE_NFS_INODE_EVENT_DONE(nfs_setattr_exit);
DEFINE_NFS_INODE_EVENT(nfs_writeback_inode_enter);
DEFINE_NFS_INODE_EVENT_DONE(nfs_writeback_inode_exit);
DEFINE_NFS_INODE_EVENT(nfs_fsync_enter);
DEFINE_NFS_INODE_EVENT_DONE(nfs_fsync_exit);
DEFINE_NFS_INODE_EVENT(nfs_access_enter);
DEFINE_NFS_INODE_EVENT(nfs_set_cache_invalid);
DEFINE_NFS_INODE_EVENT(nfs_readdir_force_readdirplus);
DEFINE_NFS_INODE_EVENT_DONE(nfs_readdir_cache_fill_done);
DEFINE_NFS_INODE_EVENT_DONE(nfs_readdir_uncached_done);
DEFINE_NFS_INODE_EVENT(nfs_optlockflush_zap_avoided);
DEFINE_NFS_INODE_EVENT(nfs_inode_zap_access_cache);
DEFINE_NFS_INODE_EVENT(nfs_dir_invalidate_cache);

DECLARE_EVENT_CLASS(nfs_readdir_dir_event,
		TP_PROTO(
			const struct dentry *dentry,
			const struct dir_context *ctx,
			bool clear_cache,
			bool plus
		),

		TP_ARGS(dentry, ctx, clear_cache, plus),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, nfssrv_trid)
			__field(u32, server_idx1)
			__field(u64, fileid)
			__field(u64, dpos)
			__string(name, nfs_show_dname(dentry))
			__field(bool, clear_cache)
			__field(bool, plus)
		),

		TP_fast_assign(
			const struct inode *inode = d_inode(dentry);
			const struct nfs_inode *nfsi = NFS_I(inode);
			struct nfs_server *server = NFS_SERVER(inode);

			__entry->dev = inode ? inode->i_sb->s_dev : 0;
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__entry->server_idx1 = nfsi->server_idx1;
			__entry->fileid = nfsi->fileid;
			__assign_str_wrap(name, nfs_show_dname(dentry));
			__entry->dpos = ctx->pos;
			__entry->clear_cache = clear_cache;
			__entry->plus = plus;
		),

		TP_printk(
			"nfssrv_trid=%d fileid=%02x:%02x:%llu server_idx1=%d "
			"dirname %s pos:%llu clear_cache:%d plus:%d",
			__entry->nfssrv_trid, MAJOR(__entry->dev),
			MINOR(__entry->dev), __entry->fileid,
			__entry->server_idx1, __get_str(name), __entry->dpos,
			__entry->clear_cache, __entry->plus
		)
);

#define DEFINE_NFS_READDIR_DIR_EVENT(name) \
	DEFINE_EVENT(nfs_readdir_dir_event, name, \
			TP_PROTO( \
				const struct dentry *dentry, \
				const struct dir_context *ctx, \
				bool clear_cache, \
				bool plus \
			), \
			TP_ARGS(dentry, ctx, clear_cache, plus))

DEFINE_NFS_READDIR_DIR_EVENT(nfs_readdir_dir_enter);
DEFINE_NFS_READDIR_DIR_EVENT(nfs_readdir_dir_exit);

DECLARE_EVENT_CLASS(nfs_readdir_search_pagecache_event,
		TP_PROTO(
			const struct dentry *dentry,
			pgoff_t page_index,
			u64 dir_cookie,
			u64 last_cookie,
			int result
		),

		TP_ARGS(dentry, page_index, dir_cookie, last_cookie, result),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, nfssrv_trid)
			__field(u32, server_idx1)
			__field(u64, fileid)
			__string(name, nfs_show_dname(dentry))
			__field(u64, page_index)
			__field(u64, dir_cookie)
			__field(u64, last_cookie)
			__field(unsigned, error)
		),

		TP_fast_assign(
			const struct inode *inode = d_inode(dentry);
			const struct nfs_inode *nfsi = NFS_I(inode);
			struct nfs_server *server = NFS_SERVER(inode);

			__entry->dev = inode ? inode->i_sb->s_dev : 0;
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__entry->server_idx1 = nfsi->server_idx1;
			__entry->fileid = nfsi->fileid;
			__assign_str_wrap(name, nfs_show_dname(dentry));
			__entry->page_index = page_index;
			__entry->dir_cookie = dir_cookie;
			__entry->last_cookie = last_cookie;
			__entry->error = (result < 0 ? -result : 0);
		),

		TP_printk(
			"nfssrv_trid=%d fileid=%02x:%02x:%llu server_idx1=%d "
			"name %s page_index:%llu dir_cookie:%llu "
			"last_cookie:%llu error:%u", __entry->nfssrv_trid,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			__entry->fileid, __entry->server_idx1, __get_str(name),
			__entry->page_index, __entry->dir_cookie,
			__entry->last_cookie, __entry->error
		)
);

DEFINE_EVENT(nfs_readdir_search_pagecache_event, nfs_readdir_search_pagecache_enter,
		TP_PROTO(const struct dentry *dentry, pgoff_t page_index,
				u64 dir_cookie, u64 last_cookie, int result),
		TP_ARGS(dentry, page_index, dir_cookie, last_cookie, result));

DEFINE_EVENT(nfs_readdir_search_pagecache_event, nfs_readdir_search_pagecache_exit,
		TP_PROTO(const struct dentry *dentry, pgoff_t page_index,
				u64 dir_cookie, u64 last_cookie, int result),
		TP_ARGS(dentry, page_index, dir_cookie, last_cookie, result));


DECLARE_EVENT_CLASS(nfs3proc_fh_event_class,
		TP_PROTO(
			const struct rpc_task *task,
			const struct nfs_server *server,
			const struct nfs_fh *fhandle
		),

		TP_ARGS(task, server, fhandle),

		TP_STRUCT__entry(
			__field(u64, task_id)
			__field(unsigned int, client_id)
			__field(unsigned int, nfssrv_trid)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob, fhandle->size)
		),

		TP_fast_assign(
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__entry->task_id = task->tk_pid;
			__entry->client_id = task->tk_client->cl_clid;
			__entry->fhandle = nfs_fhandle_hash(fhandle);
			__entry->fhandle_size = fhandle->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fhandle->data[0],
			       __entry->fhandle_size);
		),

		TP_printk("nfssrv_trid=%d "
			SUNRPC_TRACE_TASK_SPECIFIER " fhandle=0x%08x %s",
			__entry->nfssrv_trid,
			__entry->task_id, __entry->client_id,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1)
		)
);

#define DEFINE_NFS3PROC_FH_EVENT(name) \
	DEFINE_EVENT(nfs3proc_fh_event_class, name, \
		TP_PROTO( \
			const struct rpc_task *task, \
			const struct nfs_server *server, \
			const struct nfs_fh *fhandle \
		), \
		TP_ARGS(task, server, fhandle) \
	) \

DEFINE_NFS3PROC_FH_EVENT(nfs3proc_fsinfo);
DEFINE_NFS3PROC_FH_EVENT(nfs3proc_getattr);
DEFINE_NFS3PROC_FH_EVENT(nfs3proc_access);
DEFINE_NFS3PROC_FH_EVENT(nfs3proc_readdir);
DEFINE_NFS3PROC_FH_EVENT(nfs3proc_readdirplus);
DEFINE_NFS3PROC_FH_EVENT(nfs3proc_lookup);
DEFINE_NFS3PROC_FH_EVENT(nfs3proc_create);
DEFINE_NFS3PROC_FH_EVENT(nfs3proc_remove);

TRACE_EVENT(nfs_access_exit,
		TP_PROTO(
			const struct inode *inode,
			unsigned int mask,
			unsigned int permitted,
			int error
		),

		TP_ARGS(inode, mask, permitted, error),

		TP_STRUCT__entry(
			__field(unsigned long, error)
			__field(dev_t, dev)
			__field(unsigned int, nfssrv_trid)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob, NFS_I(inode)->fh.size)
			__field(unsigned char, type)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, size)
			__field(unsigned long, nfsi_flags)
			__field(unsigned long, cache_validity)
			__field(unsigned int, mask)
			__field(unsigned int, permitted)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);
			struct nfs_server *server = NFS_SERVER(inode);

			__entry->error = error < 0 ? -error : 0;
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->fhandle_size = nfsi->fh.size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &nfsi->fh.data[0],
			       __entry->fhandle_size);
			__entry->type = nfs_umode_to_dtype(inode->i_mode);
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->size = i_size_read(inode);
			__entry->nfsi_flags = nfsi->flags;
			__entry->cache_validity = nfsi->cache_validity;
			__entry->mask = mask;
			__entry->permitted = permitted;
		),

		TP_printk(
			"error=%ld (%s) nfssrv_trid=%d fileid=%02x:%02x:%llu "
			"fhandle=0x%08x %s type=%u (%s) version=%llu size=%lld "
			"cache_validity=0x%lx (%s) nfs_flags=0x%lx (%s) "
			"mask=0x%x permitted=0x%x",
			-__entry->error, show_nfs_status(__entry->error),
			__entry->nfssrv_trid,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1),
			__entry->type,
			show_fs_dirent_type(__entry->type),
			(unsigned long long)__entry->version,
			(long long)__entry->size,
			__entry->cache_validity,
			nfs_show_cache_validity(__entry->cache_validity),
			__entry->nfsi_flags,
			nfs_show_nfsi_flags(__entry->nfsi_flags),
			__entry->mask, __entry->permitted
		)
);

DECLARE_EVENT_CLASS(nfs_update_size_class,
		TP_PROTO(
			const struct inode *inode,
			loff_t new_size
		),

		TP_ARGS(inode, new_size),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, cur_size)
			__field(loff_t, new_size)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->fileid = nfsi->fileid;
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->cur_size = i_size_read(inode);
			__entry->new_size = new_size;
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x version=%llu cursize=%lld newsize=%lld",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->version,
			__entry->cur_size, __entry->new_size
		)
);

#define DEFINE_NFS_UPDATE_SIZE_EVENT(name) \
	DEFINE_EVENT(nfs_update_size_class, nfs_size_##name, \
			TP_PROTO( \
				const struct inode *inode, \
				loff_t new_size \
			), \
			TP_ARGS(inode, new_size))

DEFINE_NFS_UPDATE_SIZE_EVENT(truncate);
DEFINE_NFS_UPDATE_SIZE_EVENT(wcc);
DEFINE_NFS_UPDATE_SIZE_EVENT(update);
DEFINE_NFS_UPDATE_SIZE_EVENT(grow);

DECLARE_EVENT_CLASS(nfs_inode_range_event,
		TP_PROTO(
			const struct inode *inode,
			loff_t range_start,
			loff_t range_end
		),

		TP_ARGS(inode, range_start, range_end),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, range_start)
			__field(loff_t, range_end)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->fileid = nfsi->fileid;
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->range_start = range_start;
			__entry->range_end = range_end;
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x version=%llu "
			"range=[%lld, %lld]",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->version,
			__entry->range_start, __entry->range_end
		)
);

#define DEFINE_NFS_INODE_RANGE_EVENT(name) \
	DEFINE_EVENT(nfs_inode_range_event, name, \
			TP_PROTO( \
				const struct inode *inode, \
				loff_t range_start, \
				loff_t range_end \
			), \
			TP_ARGS(inode, range_start, range_end))

DEFINE_NFS_INODE_RANGE_EVENT(nfs_readdir_invalidate_cache_range);

DECLARE_EVENT_CLASS(nfs_readdir_event,
		TP_PROTO(
			const struct file *file,
			const __be32 *verifier,
			u64 cookie,
			pgoff_t page_index,
			unsigned int dtsize
		),

		TP_ARGS(file, verifier, cookie, page_index, dtsize),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(u64, version)
			__array(char, verifier, NFS4_VERIFIER_SIZE)
			__field(u64, cookie)
			__field(pgoff_t, index)
			__field(unsigned int, dtsize)
		),

		TP_fast_assign(
			const struct inode *dir = file_inode(file);
			const struct nfs_inode *nfsi = NFS_I(dir);

			__entry->dev = dir->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->version = inode_peek_iversion_raw(dir);
			if (cookie != 0)
				memcpy(__entry->verifier, verifier,
				       NFS4_VERIFIER_SIZE);
			else
				memset(__entry->verifier, 0,
				       NFS4_VERIFIER_SIZE);
			__entry->cookie = cookie;
			__entry->index = page_index;
			__entry->dtsize = dtsize;
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x version=%llu "
			"cookie=%s:0x%llx cache_index=%lu dtsize=%u",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid, __entry->fhandle,
			__entry->version, show_nfs4_verifier(__entry->verifier),
			(unsigned long long)__entry->cookie, __entry->index,
			__entry->dtsize
		)
);

#define DEFINE_NFS_READDIR_EVENT(name) \
	DEFINE_EVENT(nfs_readdir_event, name, \
			TP_PROTO( \
				const struct file *file, \
				const __be32 *verifier, \
				u64 cookie, \
				pgoff_t page_index, \
				unsigned int dtsize \
				), \
			TP_ARGS(file, verifier, cookie, page_index, dtsize))

DEFINE_NFS_READDIR_EVENT(nfs_readdir_cache_fill);
DEFINE_NFS_READDIR_EVENT(nfs_readdir_uncached);

DECLARE_EVENT_CLASS(nfs_lookup_event,
		TP_PROTO(
			const struct inode *dir,
			const struct dentry *dentry,
			unsigned long flags
		),

		TP_ARGS(dir, dentry, flags),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u64, dir)
			__field(u64, fileid)
			__string(name, nfs_show_dname(dentry))
			__field(unsigned long, flags)
		),

		TP_fast_assign(
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__entry->flags = flags;
			__entry->fileid = d_is_negative(dentry) ? 0 : NFS_FILEID(d_inode(dentry));
			__assign_str_wrap(name, nfs_show_dname(dentry));
		),

		TP_printk(
			"flags=0x%lx (%s) name=%02x:%02x:%llu/%llu:%s",
			__entry->flags, show_fs_lookup_flags(__entry->flags),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			(unsigned long long)__entry->fileid,
			__get_str(name)
		)
);

#define DEFINE_NFS_LOOKUP_EVENT(name) \
	DEFINE_EVENT(nfs_lookup_event, name, \
			TP_PROTO( \
				const struct inode *dir, \
				const struct dentry *dentry, \
				unsigned long flags \
			), \
			TP_ARGS(dir, dentry, flags))

DECLARE_EVENT_CLASS(nfs_lookup_event_done,
		TP_PROTO(
			const struct inode *dir,
			const struct dentry *dentry,
			unsigned long flags,
			int error
		),

		TP_ARGS(dir, dentry, flags, error),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u64, dir)
			__field(u64, fileid)
			__string(name, nfs_show_dname(dentry))
			__field(unsigned long, flags)
			__field(int, error)
			__field(int, ret)
		),

		TP_fast_assign(
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__entry->error = error < 0 ? -error : 0;
			__entry->flags = flags;
			__entry->fileid = d_is_negative(dentry) ? 0 : NFS_FILEID(d_inode(dentry));
			__assign_str_wrap(name, nfs_show_dname(dentry));
			__entry->error = error < 0 ? -error : 0;
			__entry->ret = error >= 0 ? error : 0;
		),

		TP_printk(
			"error=%d (%s) ret=%d flags=0x%lx (%s) name="
			"%02x:%02x:%llu/%llu:%s", -__entry->error,
			show_nfs_status(__entry->error), __entry->ret,
			__entry->flags, show_fs_lookup_flags(__entry->flags),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			(unsigned long long)__entry->fileid,
			__get_str(name)
		)
);

#define DEFINE_NFS_LOOKUP_EVENT_DONE(name) \
	DEFINE_EVENT(nfs_lookup_event_done, name, \
			TP_PROTO( \
				const struct inode *dir, \
				const struct dentry *dentry, \
				unsigned long flags, \
				int error \
			), \
			TP_ARGS(dir, dentry, flags, error))

DEFINE_NFS_LOOKUP_EVENT(nfs4_do_lookup_revalidate);
DEFINE_NFS_LOOKUP_EVENT(nfs_do_lookup_revalidate);
DEFINE_NFS_LOOKUP_EVENT(nfs_lookup_enter);
DEFINE_NFS_LOOKUP_EVENT_DONE(nfs_lookup_exit);
DEFINE_NFS_LOOKUP_EVENT(nfs_lookup_revalidate_enter);
DEFINE_NFS_LOOKUP_EVENT_DONE(nfs_lookup_revalidate_exit);
DEFINE_NFS_LOOKUP_EVENT(nfs_readdir_lookup);
DEFINE_NFS_LOOKUP_EVENT(nfs_readdir_lookup_revalidate_failed);
DEFINE_NFS_LOOKUP_EVENT_DONE(nfs_readdir_lookup_revalidate);

TRACE_EVENT(nfs_fhget_inode,
		TP_PROTO(
			const struct inode *inode,
			const struct dentry *dentry
		),

		TP_ARGS(inode, dentry),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, nfssrv_trid)
			__field(u64, fileid)
			__string(name, nfs_show_dname(dentry))
		),

		TP_fast_assign(
			struct nfs_server *server = IS_ERR_OR_NULL(inode) ? NULL : NFS_SERVER(inode);
			__entry->dev = IS_ERR_OR_NULL(inode) ? 0 : inode->i_sb->s_dev;
			__entry->fileid = IS_ERR_OR_NULL(inode) ? 0 : NFS_FILEID(inode);
			__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
			__assign_str_wrap(name, nfs_show_dname(dentry));
		),

		TP_printk(
                       "dev %02x:%02x name %s fileid %llu",
                       MAJOR(__entry->dev), MINOR(__entry->dev),
		       __get_str(name), (unsigned long long)__entry->fileid
               )
);

TRACE_EVENT(nfs_atomic_open_enter,
		TP_PROTO(
			const struct inode *dir,
			const struct nfs_open_context *ctx,
			unsigned int flags
		),

		TP_ARGS(dir, ctx, flags),

		TP_STRUCT__entry(
			__field(unsigned long, flags)
			__field(unsigned long, fmode)
			__field(dev_t, dev)
			__field(u64, dir)
			__string(name, nfs_show_dname(ctx->dentry))
		),

		TP_fast_assign(
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__entry->flags = flags;
			__entry->fmode = (__force unsigned long)ctx->mode;
			__assign_str_wrap(name, nfs_show_dname(ctx->dentry));
		),

		TP_printk(
			"flags=0x%lx (%s) fmode=%s name=%02x:%02x:%llu/%s",
			__entry->flags,
			show_fs_fcntl_open_flags(__entry->flags),
			show_fs_fmode_flags(__entry->fmode),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

TRACE_EVENT(nfs_atomic_open_exit,
		TP_PROTO(
			const struct inode *dir,
			const struct nfs_open_context *ctx,
			unsigned int flags,
			int error
		),

		TP_ARGS(dir, ctx, flags, error),

		TP_STRUCT__entry(
			__field(unsigned long, error)
			__field(unsigned long, flags)
			__field(unsigned long, fmode)
			__field(dev_t, dev)
			__field(u64, dir)
			__string(name, nfs_show_dname(ctx->dentry))
		),

		TP_fast_assign(
			__entry->error = -error;
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__entry->flags = flags;
			__entry->fmode = (__force unsigned long)ctx->mode;
			__assign_str_wrap(name, nfs_show_dname(ctx->dentry));
		),

		TP_printk(
			"error=%ld (%s) flags=0x%lx (%s) fmode=%s "
			"name=%02x:%02x:%llu/%s",
			-__entry->error, show_nfs_status(__entry->error),
			__entry->flags,
			show_fs_fcntl_open_flags(__entry->flags),
			show_fs_fmode_flags(__entry->fmode),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

TRACE_EVENT(nfs_create_enter,
		TP_PROTO(
			const struct inode *dir,
			const struct dentry *dentry,
			unsigned int flags
		),

		TP_ARGS(dir, dentry, flags),

		TP_STRUCT__entry(
			__field(unsigned long, flags)
			__field(dev_t, dev)
			__field(u64, dir)
			__string(name, nfs_show_dname(dentry))
		),

		TP_fast_assign(
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__entry->flags = flags;
			__assign_str_wrap(name, nfs_show_dname(dentry));
		),

		TP_printk(
			"flags=0x%lx (%s) name=%02x:%02x:%llu/%s",
			__entry->flags,
			show_fs_fcntl_open_flags(__entry->flags),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

TRACE_EVENT(nfs_create_exit,
		TP_PROTO(
			const struct inode *dir,
			const struct dentry *dentry,
			unsigned int flags,
			int error
		),

		TP_ARGS(dir, dentry, flags, error),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u64, dirid)
			__field(u64, fileid)
			__string(name, nfs_show_dname(dentry))
			__field(unsigned int, flags)
			__field(int, error)
		),

		TP_fast_assign(
			const struct inode *inode = d_inode(dentry);
			__entry->dev = dir->i_sb->s_dev;
			__entry->dirid = NFS_FILEID(dir);
			__entry->fileid = inode ? NFS_FILEID(inode) : 0;
			__assign_str_wrap(name, nfs_show_dname(dentry));
			__entry->flags = flags;
			__entry->error = -error;
		),

		TP_printk(
			"error=%d (%s) flags=0x%x (%s) dir=%02x:%02x:%llu name=%llu/%s",
			-__entry->error, show_nfs_status(__entry->error),
			__entry->flags, show_fs_fcntl_open_flags(__entry->flags),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dirid,
			(unsigned long long)__entry->fileid, __get_str(name)
		)
);

DECLARE_EVENT_CLASS(nfs_directory_event,
		TP_PROTO(
			const struct inode *dir,
			const struct dentry *dentry
		),

		TP_ARGS(dir, dentry),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u64, dir)
			__string(name, nfs_show_dname(dentry))
		),

		TP_fast_assign(
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__assign_str_wrap(name, nfs_show_dname(dentry));
		),

		TP_printk(
			"name=%02x:%02x:%llu/%s",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

#define DEFINE_NFS_DIRECTORY_EVENT(name) \
	DEFINE_EVENT(nfs_directory_event, name, \
			TP_PROTO( \
				const struct inode *dir, \
				const struct dentry *dentry \
			), \
			TP_ARGS(dir, dentry))

DECLARE_EVENT_CLASS(nfs_directory_event_done,
		TP_PROTO(
			const struct inode *dir,
			const struct dentry *dentry,
			int error
		),

		TP_ARGS(dir, dentry, error),

		TP_STRUCT__entry(
			__field(unsigned long, error)
			__field(dev_t, dev)
			__field(u64, dir)
			__string(name, nfs_show_dname(dentry))
		),

		TP_fast_assign(
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__entry->error = error < 0 ? -error : 0;
			__assign_str_wrap(name, nfs_show_dname(dentry));
		),

		TP_printk(
			"error=%ld (%s) name=%02x:%02x:%llu/%s",
			-__entry->error, show_nfs_status(__entry->error),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

#define DEFINE_NFS_DIRECTORY_EVENT_DONE(name) \
	DEFINE_EVENT(nfs_directory_event_done, name, \
			TP_PROTO( \
				const struct inode *dir, \
				const struct dentry *dentry, \
				int error \
			), \
			TP_ARGS(dir, dentry, error))

DEFINE_NFS_DIRECTORY_EVENT(nfs_mknod_enter);
DEFINE_NFS_DIRECTORY_EVENT_DONE(nfs_mknod_exit);
DEFINE_NFS_DIRECTORY_EVENT(nfs_mkdir_enter);
DEFINE_NFS_DIRECTORY_EVENT_DONE(nfs_mkdir_exit);
DEFINE_NFS_DIRECTORY_EVENT(nfs_rmdir_enter);
DEFINE_NFS_DIRECTORY_EVENT_DONE(nfs_rmdir_exit);
DEFINE_NFS_DIRECTORY_EVENT(nfs_remove_enter);
DEFINE_NFS_DIRECTORY_EVENT_DONE(nfs_remove_exit);
DEFINE_NFS_DIRECTORY_EVENT(nfs_unlink_enter);
DEFINE_NFS_DIRECTORY_EVENT_DONE(nfs_unlink_exit);
DEFINE_NFS_DIRECTORY_EVENT(nfs_symlink_enter);
DEFINE_NFS_DIRECTORY_EVENT_DONE(nfs_symlink_exit);

TRACE_EVENT(nfs_link_enter,
		TP_PROTO(
			const struct inode *inode,
			const struct inode *dir,
			const struct dentry *dentry
		),

		TP_ARGS(inode, dir, dentry),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u64, fileid)
			__field(u64, dir)
			__string(name, nfs_show_dname(dentry))
		),

		TP_fast_assign(
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = NFS_FILEID(inode);
			__entry->dir = NFS_FILEID(dir);
			__assign_str_wrap(name, nfs_show_dname(dentry));
		),

		TP_printk(
			"fileid=%02x:%02x:%llu name=%02x:%02x:%llu/%s",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			__entry->fileid,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

TRACE_EVENT(nfs_link_exit,
		TP_PROTO(
			const struct inode *inode,
			const struct inode *dir,
			const struct dentry *dentry,
			int error
		),

		TP_ARGS(inode, dir, dentry, error),

		TP_STRUCT__entry(
			__field(unsigned long, error)
			__field(dev_t, dev)
			__field(u64, fileid)
			__field(u64, dir)
			__string(name, nfs_show_dname(dentry))
		),

		TP_fast_assign(
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = NFS_FILEID(inode);
			__entry->dir = NFS_FILEID(dir);
			__entry->error = error < 0 ? -error : 0;
			__assign_str_wrap(name, nfs_show_dname(dentry));
		),

		TP_printk(
			"error=%ld (%s) fileid=%02x:%02x:%llu name=%02x:%02x:%llu/%s",
			-__entry->error, show_nfs_status(__entry->error),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			__entry->fileid,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

DECLARE_EVENT_CLASS(nfs_rename_event,
		TP_PROTO(
			const struct inode *old_dir,
			const struct dentry *old_dentry,
			const struct inode *new_dir,
			const struct dentry *new_dentry
		),

		TP_ARGS(old_dir, old_dentry, new_dir, new_dentry),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u64, old_dir)
			__field(u64, new_dir)
			__string(old_name, nfs_show_dname(old_dentry))
			__string(new_name, nfs_show_dname(new_dentry))
		),

		TP_fast_assign(
			__entry->dev = old_dir->i_sb->s_dev;
			__entry->old_dir = NFS_FILEID(old_dir);
			__entry->new_dir = NFS_FILEID(new_dir);
			__assign_str_wrap(old_name, nfs_show_dname(old_dentry));
			__assign_str_wrap(new_name, nfs_show_dname(new_dentry));
		),

		TP_printk(
			"old_name=%02x:%02x:%llu/%s new_name=%02x:%02x:%llu/%s",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->old_dir,
			__get_str(old_name),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->new_dir,
			__get_str(new_name)
		)
);
#define DEFINE_NFS_RENAME_EVENT(name) \
	DEFINE_EVENT(nfs_rename_event, name, \
			TP_PROTO( \
				const struct inode *old_dir, \
				const struct dentry *old_dentry, \
				const struct inode *new_dir, \
				const struct dentry *new_dentry \
			), \
			TP_ARGS(old_dir, old_dentry, new_dir, new_dentry))

DECLARE_EVENT_CLASS(nfs_rename_event_done,
		TP_PROTO(
			const struct inode *old_dir,
			const struct dentry *old_dentry,
			const struct inode *new_dir,
			const struct dentry *new_dentry,
			int error
		),

		TP_ARGS(old_dir, old_dentry, new_dir, new_dentry, error),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(unsigned long, error)
			__field(u64, old_dir)
			__string(old_name, nfs_show_dname(old_dentry))
			__field(u64, new_dir)
			__string(new_name, nfs_show_dname(new_dentry))
		),

		TP_fast_assign(
			__entry->dev = old_dir->i_sb->s_dev;
			__entry->error = -error;
			__entry->old_dir = NFS_FILEID(old_dir);
			__entry->new_dir = NFS_FILEID(new_dir);
			__assign_str_wrap(old_name, nfs_show_dname(old_dentry));
			__assign_str_wrap(new_name, nfs_show_dname(new_dentry));
		),

		TP_printk(
			"error=%ld (%s) old_name=%02x:%02x:%llu/%s "
			"new_name=%02x:%02x:%llu/%s",
			-__entry->error, show_nfs_status(__entry->error),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->old_dir,
			__get_str(old_name),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->new_dir,
			__get_str(new_name)
		)
);
#define DEFINE_NFS_RENAME_EVENT_DONE(name) \
	DEFINE_EVENT(nfs_rename_event_done, name, \
			TP_PROTO( \
				const struct inode *old_dir, \
				const struct dentry *old_dentry, \
				const struct inode *new_dir, \
				const struct dentry *new_dentry, \
				int error \
			), \
			TP_ARGS(old_dir, old_dentry, new_dir, \
				new_dentry, error))

DEFINE_NFS_RENAME_EVENT(nfs_rename_enter);
DEFINE_NFS_RENAME_EVENT_DONE(nfs_rename_exit);

DEFINE_NFS_RENAME_EVENT_DONE(nfs_async_rename_done);

TRACE_EVENT(nfs_sillyrename_unlink,
		TP_PROTO(
			const struct nfs_unlinkdata *data,
			int error
		),

		TP_ARGS(data, error),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(unsigned long, error)
			__field(u64, dir)
			__dynamic_array(char, name, data->args.name.len + 1)
		),

		TP_fast_assign(
			struct inode *dir = d_inode(data->dentry->d_parent);
			size_t len = data->args.name.len;
			__entry->dev = dir->i_sb->s_dev;
			__entry->dir = NFS_FILEID(dir);
			__entry->error = -error;
			memcpy(__get_str(name),
				data->args.name.name, len);
			__get_str(name)[len] = 0;
		),

		TP_printk(
			"error=%ld (%s) name=%02x:%02x:%llu/%s",
			-__entry->error, show_nfs_status(__entry->error),
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->dir,
			__get_str(name)
		)
);

DECLARE_EVENT_CLASS(nfs_folio_event,
		TP_PROTO(
			const struct inode *inode,
			loff_t offset,
			size_t count
		),

		TP_ARGS(inode, offset, count),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, offset)
			__field(size_t, count)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->offset = offset;
			__entry->count = count;
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x version=%llu "
			"offset=%lld count=%zu",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->version,
			__entry->offset, __entry->count
		)
);

#define DEFINE_NFS_FOLIO_EVENT(name) \
	DEFINE_EVENT(nfs_folio_event, name, \
			TP_PROTO( \
				const struct inode *inode, \
				loff_t offset, \
				size_t count \
			), \
			TP_ARGS(inode, offset, count))

DECLARE_EVENT_CLASS(nfs_folio_event_done,
		TP_PROTO(
			const struct inode *inode,
			loff_t offset,
			size_t count,
			int ret
		),

		TP_ARGS(inode, offset, count, ret),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(int, ret)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, offset)
			__field(size_t, count)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->offset = offset;
			__entry->count = count;
			__entry->ret = ret;
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x version=%llu "
			"offset=%lld count=%zu ret=%d",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->version,
			__entry->offset, __entry->count, __entry->ret
		)
);

#define DEFINE_NFS_FOLIO_EVENT_DONE(name) \
	DEFINE_EVENT(nfs_folio_event_done, name, \
			TP_PROTO( \
				const struct inode *inode, \
				loff_t offset, \
				size_t count, \
				int ret \
			), \
			TP_ARGS(inode, offset, count, ret))

DEFINE_NFS_FOLIO_EVENT(nfs_aop_readpage);
DEFINE_NFS_FOLIO_EVENT_DONE(nfs_aop_readpage_done);

DEFINE_NFS_FOLIO_EVENT(nfs_writeback_folio);
DEFINE_NFS_FOLIO_EVENT_DONE(nfs_writeback_folio_done);

DEFINE_NFS_FOLIO_EVENT(nfs_invalidate_folio);
DEFINE_NFS_FOLIO_EVENT_DONE(nfs_launder_folio_done);

TRACE_EVENT(nfs_aop_readahead,
		TP_PROTO(
			const struct file *file,
			const struct inode *inode,
			loff_t pos,
			unsigned int nr_pages,
			bool expanded,
			size_t ra_expansion_size,
			struct nfs_ctx_readahead *ra_entry,
			bool enable,
			bool mmap_enabled
		),

		TP_ARGS(file, inode, pos, nr_pages, expanded, ra_expansion_size, ra_entry, enable, mmap_enabled),

		TP_STRUCT__entry(
			__field(const struct file *, file)
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, offset)
			__field(unsigned int, nr_pages)
			__field(bool, expanded)
			__field(size_t, ra_expansion_size)
			__field(size_t, current_ra_size)
			__field(bool, expanding_readahead_enable)
			__field(bool, expanding_readahead_mmap_enable)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->file = file;
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->offset = pos;
			__entry->nr_pages = nr_pages;
			__entry->expanded = expanded;
			__entry->ra_expansion_size = ra_expansion_size;
			__entry->current_ra_size = ra_entry ? ra_entry->current_ra_size : 0;
			__entry->expanding_readahead_enable = enable;
			__entry->expanding_readahead_mmap_enable = mmap_enabled;
		),

		TP_printk(
			"file=%p fileid=%02x:%02x:%llu fhandle=0x%08x version=%llu offset=%lld nr_pages=%u expanded=%s expansion_size=%zu current_ra_size=%zu expanding=(fadvice:%s, mmap:%s)",
			__entry->file, MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->version,
			__entry->offset, __entry->nr_pages,
			__entry->expanded ? "yes" : "no",
			__entry->ra_expansion_size,
			__entry->current_ra_size,
			__entry->expanding_readahead_enable ? "yes" : "no",
			__entry->expanding_readahead_mmap_enable ? "yes" : "no"
		)
);

TRACE_EVENT(nfs_aop_readahead_done,
		TP_PROTO(
			const struct inode *inode,
			unsigned int nr_pages,
			int ret
		),

		TP_ARGS(inode, nr_pages, ret),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(int, ret)
			__field(u64, fileid)
			__field(u64, version)
			__field(loff_t, offset)
			__field(unsigned int, nr_pages)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->version = inode_peek_iversion_raw(inode);
			__entry->nr_pages = nr_pages;
			__entry->ret = ret;
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x version=%llu nr_pages=%u ret=%d",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->version,
			__entry->nr_pages, __entry->ret
		)
);

TRACE_EVENT(nfs_ra_pages_set,
		TP_PROTO(
			const struct file *file,
			unsigned long ra_pages,
			const char *callsite
		),

		TP_ARGS(file, ra_pages, callsite),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(const struct file *, file)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(unsigned long, ra_pages)
			__string(callsite, callsite)
		),

		TP_fast_assign(
			const struct inode *inode = file_inode(file);
			const struct nfs_inode *nfsi = NFS_I(inode);

			__entry->dev = inode->i_sb->s_dev;
			__entry->file = file;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->ra_pages = ra_pages;
			__assign_str_wrap(callsite, callsite);
		),

		TP_printk(
			"file=%p fileid=%02x:%02x:%llu fhandle=0x%08x ra_pages=%lu callsite=%s",
			__entry->file, MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__entry->ra_pages, __get_str(callsite)
		)
);

TRACE_EVENT(nfs_initiate_read,
		TP_PROTO(
			const struct nfs_pgio_header *hdr
		),

		TP_ARGS(hdr),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob,
				(hdr->args.fh ? hdr->args.fh :
				 &NFS_I(hdr->inode)->fh)->size)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(u32, count)
		),

		TP_fast_assign(
			const struct inode *inode = hdr->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = hdr->args.fh ?
						  hdr->args.fh : &nfsi->fh;

			__entry->offset = hdr->args.offset;
			__entry->count = hdr->args.count;
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x %s "
			"offset=%lld count=%u",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
                                      __entry->fhandle_size, 1),
			(long long)__entry->offset, __entry->count
		)
);

TRACE_EVENT(nfs_readpage_done,
		TP_PROTO(
			const struct rpc_task *task,
			const struct nfs_pgio_header *hdr
		),

		TP_ARGS(task, hdr),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob,
				(hdr->args.fh ? hdr->args.fh :
				 &NFS_I(hdr->inode)->fh)->size)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(u32, arg_count)
			__field(u32, res_count)
			__field(bool, eof)
			__field(int, error)
		),

		TP_fast_assign(
			const struct inode *inode = hdr->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = hdr->args.fh ?
						  hdr->args.fh : &nfsi->fh;

			__entry->error = task->tk_status;
			__entry->offset = hdr->args.offset;
			__entry->arg_count = hdr->args.count;
			__entry->res_count = hdr->res.count;
			__entry->eof = hdr->res.eof;
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
                        "error=%d fileid=%02x:%02x:%llu fhandle=0x%08x %s "
                        "offset=%lld count=%u res=%u%s", __entry->error,
                        MAJOR(__entry->dev), MINOR(__entry->dev),
                        (unsigned long long)__entry->fileid,
                        __entry->fhandle,
			__field(u16, fhandle_size)
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1),
			(long long)__entry->offset, __entry->arg_count,
			__entry->res_count, __entry->eof ? " eof" : ""
		)
);

TRACE_EVENT(nfs_readpage_short,
		TP_PROTO(
			const struct rpc_task *task,
			const struct nfs_pgio_header *hdr
		),

		TP_ARGS(task, hdr),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob,
				(hdr->args.fh ? hdr->args.fh :
				 &NFS_I(hdr->inode)->fh)->size)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(u32, arg_count)
			__field(u32, res_count)
			__field(bool, eof)
			__field(int, error)
		),

		TP_fast_assign(
			const struct inode *inode = hdr->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = hdr->args.fh ?
						  hdr->args.fh : &nfsi->fh;

			__entry->error = task->tk_status;
			__entry->offset = hdr->args.offset;
			__entry->arg_count = hdr->args.count;
			__entry->res_count = hdr->res.count;
			__entry->eof = hdr->res.eof;
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
			"error=%d fileid=%02x:%02x:%llu fhandle=0x%08x %s "
			"offset=%lld count=%u res=%u%s", __entry->error,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
                                      __entry->fhandle_size, 1),
			(long long)__entry->offset, __entry->arg_count,
			__entry->res_count, __entry->eof ? " eof" : ""
		)
);


TRACE_EVENT(nfs_pgio_error,
	TP_PROTO(
		const struct nfs_pgio_header *hdr,
		int error,
		loff_t pos
	),

	TP_ARGS(hdr, error, pos),

	TP_STRUCT__entry(
		__field(dev_t, dev)
		__field(u32, fhandle)
		__field(u16, fhandle_size)
		__dynamic_array(u8, fhandle_blob,
			(hdr->args.fh ? hdr->args.fh :
			 &NFS_I(hdr->inode)->fh)->size)
		__field(u64, fileid)
		__field(loff_t, offset)
		__field(u32, arg_count)
		__field(u32, res_count)
		__field(loff_t, pos)
		__field(int, error)
	),

	TP_fast_assign(
		const struct inode *inode = hdr->inode;
		const struct nfs_inode *nfsi = NFS_I(inode);
		const struct nfs_fh *fh = hdr->args.fh ?
					  hdr->args.fh : &nfsi->fh;

		__entry->error = error;
		__entry->offset = hdr->args.offset;
		__entry->arg_count = hdr->args.count;
		__entry->res_count = hdr->res.count;
		__entry->dev = inode->i_sb->s_dev;
		__entry->fileid = nfsi->fileid;
		__entry->fhandle = nfs_fhandle_hash(fh);
		__entry->fhandle_size = fh->size;
		memcpy(__get_dynamic_array(fhandle_blob),
		       &fh->data[0], __entry->fhandle_size);
	),

	TP_printk("error=%d fileid=%02x:%02x:%llu fhandle=0x%08x %s "
		  "offset=%lld count=%u res=%u pos=%llu", __entry->error,
		MAJOR(__entry->dev), MINOR(__entry->dev),
		(unsigned long long)__entry->fileid, __entry->fhandle,
		__print_array(__get_dynamic_array(fhandle_blob),
			      __entry->fhandle_size, 1),
		(long long)__entry->offset, __entry->arg_count, __entry->res_count,
		__entry->pos
	)
);

TRACE_EVENT(nfs_initiate_write,
		TP_PROTO(
			const struct nfs_pgio_header *hdr
		),

		TP_ARGS(hdr),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob,
				(hdr->args.fh ? hdr->args.fh :
				 &NFS_I(hdr->inode)->fh)->size)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(u32, count)
			__field(unsigned long, stable)
		),

		TP_fast_assign(
			const struct inode *inode = hdr->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = hdr->args.fh ?
						  hdr->args.fh : &nfsi->fh;

			__entry->offset = hdr->args.offset;
			__entry->count = hdr->args.count;
			__entry->stable = hdr->args.stable;
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x %s "
			"offset=%lld count=%u stable=%s",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1),
			(long long)__entry->offset, __entry->count,
			show_nfs_stable_how(__entry->stable)
		)
);

TRACE_EVENT(nfs_writeback_done,
		TP_PROTO(
			const struct rpc_task *task,
			const struct nfs_pgio_header *hdr
		),

		TP_ARGS(task, hdr),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob,
				(hdr->args.fh ? hdr->args.fh :
				 &NFS_I(hdr->inode)->fh)->size)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(u32, arg_count)
			__field(u32, res_count)
			__field(int, error)
			__field(unsigned long, stable)
			__array(char, verifier, NFS4_VERIFIER_SIZE)
		),

		TP_fast_assign(
			const struct inode *inode = hdr->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = hdr->args.fh ?
						  hdr->args.fh : &nfsi->fh;
			const struct nfs_writeverf *verf = hdr->res.verf;

			__entry->error = task->tk_status;
			__entry->offset = hdr->args.offset;
			__entry->arg_count = hdr->args.count;
			__entry->res_count = hdr->res.count;
			__entry->stable = verf->committed;
			memcpy(__entry->verifier,
				&verf->verifier,
				NFS4_VERIFIER_SIZE);
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
			"error=%d fileid=%02x:%02x:%llu fhandle=0x%08x "
			"%s offset=%lld count=%u res=%u stable=%s "
			"verifier=%s", __entry->error,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1),
			(long long)__entry->offset, __entry->arg_count,
			__entry->res_count,
			show_nfs_stable_how(__entry->stable),
			show_nfs4_verifier(__entry->verifier)
		)
);

DECLARE_EVENT_CLASS(nfs_page_error_class,
		TP_PROTO(
			const struct inode *inode,
			const struct nfs_page *req,
			int error
		),

		TP_ARGS(inode, req, error),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(unsigned int, count)
			__field(int, error)
		),

		TP_fast_assign(
			const struct nfs_inode *nfsi = NFS_I(inode);
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(&nfsi->fh);
			__entry->offset = req_offset(req);
			__entry->count = req->wb_bytes;
			__entry->error = error;
		),

		TP_printk(
			"error=%d fileid=%02x:%02x:%llu fhandle=0x%08x "
			"offset=%lld count=%u", __entry->error,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->offset,
			__entry->count
		)
);

#define DEFINE_NFS_PAGEERR_EVENT(name) \
	DEFINE_EVENT(nfs_page_error_class, name, \
			TP_PROTO( \
				const struct inode *inode, \
				const struct nfs_page *req, \
				int error \
			), \
			TP_ARGS(inode, req, error))

DEFINE_NFS_PAGEERR_EVENT(nfs_write_error);
DEFINE_NFS_PAGEERR_EVENT(nfs_comp_error);
DEFINE_NFS_PAGEERR_EVENT(nfs_commit_error);

TRACE_EVENT(nfs_initiate_commit,
		TP_PROTO(
			const struct nfs_commit_data *data
		),

		TP_ARGS(data),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob,
				(data->args.fh ? data->args.fh :
				 &NFS_I(data->inode)->fh)->size)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(u32, count)
		),

		TP_fast_assign(
			const struct inode *inode = data->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = data->args.fh ?
						  data->args.fh : &nfsi->fh;

			__entry->offset = data->args.offset;
			__entry->count = data->args.count;
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
			"fileid=%02x:%02x:%llu fhandle=0x%08x %s "
			"offset=%lld count=%u",
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1),
			(long long)__entry->offset, __entry->count
		)
);

TRACE_EVENT(nfs_commit_done,
		TP_PROTO(
			const struct rpc_task *task,
			const struct nfs_commit_data *data
		),

		TP_ARGS(task, data),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob,
				(data->args.fh ? data->args.fh :
				 &NFS_I(data->inode)->fh)->size)
			__field(u64, fileid)
			__field(loff_t, offset)
			__field(int, error)
			__field(unsigned long, stable)
			__array(char, verifier, NFS4_VERIFIER_SIZE)
		),

		TP_fast_assign(
			const struct inode *inode = data->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = data->args.fh ?
						  data->args.fh : &nfsi->fh;
			const struct nfs_writeverf *verf = data->res.verf;

			__entry->error = task->tk_status;
			__entry->offset = data->args.offset;
			__entry->stable = verf->committed;
			memcpy(__entry->verifier,
				&verf->verifier,
				NFS4_VERIFIER_SIZE);
			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
			"error=%d fileid=%02x:%02x:%llu fhandle=0x%08x "
			"offset=%lld stable=%s verifier=%s", __entry->error,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			(long long)__entry->offset,
			show_nfs_stable_how(__entry->stable),
			show_nfs4_verifier(__entry->verifier)
		)
);

#define nfs_show_direct_req_flags(v) \
	__print_flags(v, "|", \
			{ NFS_ODIRECT_DO_COMMIT, "DO_COMMIT" }, \
			{ NFS_ODIRECT_RESCHED_WRITES, "RESCHED_WRITES" }, \
			{ NFS_ODIRECT_SHOULD_DIRTY, "SHOULD DIRTY" }, \
			{ NFS_ODIRECT_DONE, "DONE" } )

DECLARE_EVENT_CLASS(nfs_direct_req_class,
		TP_PROTO(
			const struct nfs_direct_req *dreq
		),

		TP_ARGS(dreq),

		TP_STRUCT__entry(
			__field(dev_t, dev)
			__field(u64, fileid)
			__field(u32, fhandle)
			__field(loff_t, offset)
			__field(ssize_t, count)
			__field(ssize_t, error)
			__field(int, flags)
		),

		TP_fast_assign(
			const struct inode *inode = dreq->inode;
			const struct nfs_inode *nfsi = NFS_I(inode);
			const struct nfs_fh *fh = &nfsi->fh;

			__entry->dev = inode->i_sb->s_dev;
			__entry->fileid = nfsi->fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->offset = dreq->io_start;
			__entry->count = dreq->count;
			__entry->error = dreq->error;
			__entry->flags = dreq->flags;
		),

		TP_printk(
			"error=%zd fileid=%02x:%02x:%llu fhandle=0x%08x "
			"offset=%lld count=%zd flags=%s",
			__entry->error, MAJOR(__entry->dev),
			MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle, __entry->offset,
			__entry->count,
			nfs_show_direct_req_flags(__entry->flags)
		)
);

#define DEFINE_NFS_DIRECT_REQ_EVENT(name) \
	DEFINE_EVENT(nfs_direct_req_class, name, \
			TP_PROTO( \
				const struct nfs_direct_req *dreq \
			), \
			TP_ARGS(dreq))

DEFINE_NFS_DIRECT_REQ_EVENT(nfs_direct_commit_complete);
DEFINE_NFS_DIRECT_REQ_EVENT(nfs_direct_resched_write);
DEFINE_NFS_DIRECT_REQ_EVENT(nfs_direct_write_complete);
DEFINE_NFS_DIRECT_REQ_EVENT(nfs_direct_write_completion);
DEFINE_NFS_DIRECT_REQ_EVENT(nfs_direct_write_schedule_iovec);
DEFINE_NFS_DIRECT_REQ_EVENT(nfs_direct_write_reschedule_io);

TRACE_EVENT(nfs_fh_to_dentry,
		TP_PROTO(
			const struct super_block *sb,
			const struct nfs_fh *fh,
			u64 fileid,
			int error
		),

		TP_ARGS(sb, fh, fileid, error),

		TP_STRUCT__entry(
			__field(int, error)
			__field(dev_t, dev)
			__field(u32, fhandle)
			__field(u16, fhandle_size)
			__dynamic_array(u8, fhandle_blob, fh->size)
			__field(u64, fileid)
		),

		TP_fast_assign(
			__entry->error = error;
			__entry->dev = sb->s_dev;
			__entry->fileid = fileid;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fhandle_size = fh->size;
			memcpy(__get_dynamic_array(fhandle_blob),
			       &fh->data[0], __entry->fhandle_size);
		),

		TP_printk(
			"error=%d fileid=%02x:%02x:%llu fhandle=0x%08x %s ",
			__entry->error,
			MAJOR(__entry->dev), MINOR(__entry->dev),
			(unsigned long long)__entry->fileid,
			__entry->fhandle,
			__print_array(__get_dynamic_array(fhandle_blob),
				      __entry->fhandle_size, 1)
		)
);

TRACE_EVENT(nfs_mount_assign,
	TP_PROTO(
		const char *option,
		const char *value
	),

	TP_ARGS(option, value),

	TP_STRUCT__entry(
		__string(option, option)
		__string(value, value)
	),

	TP_fast_assign(
		__assign_str_wrap(option, option);
		__assign_str_wrap(value, value);
	),

	TP_printk("option %s=%s",
		__get_str(option), __get_str(value)
	)
);

TRACE_EVENT(nfs_mount_option,
	TP_PROTO(
		const struct fs_parameter *param
	),

	TP_ARGS(param),

	TP_STRUCT__entry(
		__string(option, param->key)
	),

	TP_fast_assign(
		__assign_str_wrap(option, param->key);
	),

	TP_printk("option %s", __get_str(option))
);

TRACE_EVENT(nfs_mount_path,
	TP_PROTO(
		const char *path
	),

	TP_ARGS(path),

	TP_STRUCT__entry(
		__string(path, path)
	),

	TP_fast_assign(
		__assign_str_wrap(path, path);
	),

	TP_printk("path='%s'", __get_str(path))
);

TRACE_EVENT(nfs_local_open_fh,
		TP_PROTO(
			const struct nfs_fh *fh,
			fmode_t fmode,
			int error
		),

		TP_ARGS(fh, fmode, error),

		TP_STRUCT__entry(
			__field(int, error)
			__field(u32, fhandle)
			__field(unsigned int, fmode)
		),

		TP_fast_assign(
			__entry->error = error;
			__entry->fhandle = nfs_fhandle_hash(fh);
			__entry->fmode = (__force unsigned int)fmode;
		),

		TP_printk(
			"error=%d fhandle=0x%08x mode=%s",
			__entry->error,
			__entry->fhandle,
			show_fs_fmode_flags(__entry->fmode)
		)
);

DECLARE_EVENT_CLASS(nfs_local_client_event,
		TP_PROTO(
			const struct nfs_client *clp
		),

		TP_ARGS(clp),

		TP_STRUCT__entry(
			__field(unsigned int, protocol)
			__string(server, clp->cl_hostname)
		),

		TP_fast_assign(
			__entry->protocol = clp->rpc_ops->version;
			__assign_str_wrap(server, clp->cl_hostname);
		),

		TP_printk(
			"server=%s NFSv%u", __get_str(server), __entry->protocol
		)
);

#define DEFINE_NFS_LOCAL_CLIENT_EVENT(name) \
	DEFINE_EVENT(nfs_local_client_event, name, \
			TP_PROTO( \
				const struct nfs_client *clp \
			), \
			TP_ARGS(clp))

DEFINE_NFS_LOCAL_CLIENT_EVENT(nfs_local_enable);
DEFINE_NFS_LOCAL_CLIENT_EVENT(nfs_local_disable);

DECLARE_EVENT_CLASS(nfs_xdr_event,
		TP_PROTO(
			const struct xdr_stream *xdr,
			int error
		),

		TP_ARGS(xdr, error),

		TP_STRUCT__entry(
			__field(u64, task_id)
			__field(unsigned int, client_id)
			__field(u32, xid)
			__field(int, version)
			__field(unsigned long, error)
			__string(program,
				 xdr->rqst->rq_task->tk_client->cl_program->name)
			__string(procedure,
				 xdr->rqst->rq_task->tk_msg.rpc_proc->p_name)
		),

		TP_fast_assign(
			const struct rpc_rqst *rqstp = xdr->rqst;
			const struct rpc_task *task = rqstp->rq_task;

			__entry->task_id = task->tk_pid;
			__entry->client_id = task->tk_client->cl_clid;
			__entry->xid = be32_to_cpu(rqstp->rq_xid);
			__entry->version = task->tk_client->cl_vers;
			__entry->error = error;
			__assign_str_wrap(program,
				     task->tk_client->cl_program->name);
			__assign_str_wrap(procedure, task->tk_msg.rpc_proc->p_name);
		),

		TP_printk(SUNRPC_TRACE_TASK_SPECIFIER
			  " xid=0x%08x %sv%d %s error=%ld (%s)",
			__entry->task_id, __entry->client_id, __entry->xid,
			__get_str(program), __entry->version,
			__get_str(procedure), -__entry->error,
			show_nfs_status(__entry->error)
		)
);
#define DEFINE_NFS_XDR_EVENT(name) \
	DEFINE_EVENT(nfs_xdr_event, name, \
			TP_PROTO( \
				const struct xdr_stream *xdr, \
				int error \
			), \
			TP_ARGS(xdr, error))
DEFINE_NFS_XDR_EVENT(nfs_xdr_status);
DEFINE_NFS_XDR_EVENT(nfs_xdr_bad_filehandle);

/* NFS client */

TRACE_EVENT(nfs_client_new,
	TP_PROTO(
		const struct nfs_client *clp
	),

	TP_ARGS(clp),

	TP_STRUCT__entry(
		__field(unsigned int, nfsclnt_trid)
		__field(unsigned int, ver)
		__field(unsigned int, minorver)
		__field(unsigned int, nconnect)
		__field(unsigned int, max_connect)
		__field(unsigned long, flags)
		__string(proto, xprt_type_to_string(clp->cl_proto))
	),

	TP_fast_assign(
		__entry->nfsclnt_trid = clp->cl_trid;
		__entry->ver = clp->rpc_ops->version;
		__entry->minorver = clp->cl_minorversion;
		__entry->flags = clp->cl_flags;
		__entry->nconnect = clp->cl_nconnect;
		__entry->max_connect = clp->cl_max_connect;
		__assign_str_wrap(proto, xprt_type_to_string(clp->cl_proto));
	),

	TP_printk("nfsclnt_trid=%u ver=%u minorver=%u proto=%s"
		  " flags=0x%lx nconnect=%u max_connect=%u",
		  __entry->nfsclnt_trid, __entry->ver, __entry->minorver, __get_str(proto),
		  __entry->flags, __entry->nconnect, __entry->max_connect)
);

DECLARE_EVENT_CLASS(nfs_client_free_class,
	TP_PROTO(
		const struct nfs_client *clp
	),

	TP_ARGS(clp),

	TP_STRUCT__entry(
		__field(unsigned int, nfsclnt_trid)
	),

	TP_fast_assign(
		__entry->nfsclnt_trid = clp->cl_trid;
	),

	TP_printk("nfsclnt_trid=%u", __entry->nfsclnt_trid)
);

#define DEFINE_NFS_CLIENT_FREE_CLASS(name) \
	DEFINE_EVENT(nfs_client_free_class, name, \
		     TP_PROTO(const struct nfs_client *clp), \
		     TP_ARGS(clp));

DEFINE_NFS_CLIENT_FREE_CLASS(nfs_client_free_start);
DEFINE_NFS_CLIENT_FREE_CLASS(nfs_client_free_done);

/* NFS server */

TRACE_EVENT(nfs_server_new,
	TP_PROTO(
		const struct nfs_server *server
	),

	TP_ARGS(server),

	TP_STRUCT__entry(
		__field(unsigned int, nfssrv_trid)
	),

	TP_fast_assign(
		__entry->nfssrv_trid = server->s_sysfs_id;
	),

	TP_printk("nfssrv_trid=%u", __entry->nfssrv_trid)
);

TRACE_EVENT(nfs_server_bind_nfs_client,
	TP_PROTO(
		const struct nfs_server *server
	),

	TP_ARGS(server),

	TP_STRUCT__entry(
		__field(unsigned int, nfssrv_trid)
		__field(unsigned int, nfsclnt_trid)
	),

	TP_fast_assign(
		__entry->nfssrv_trid = server->s_sysfs_id;
		__entry->nfsclnt_trid = server->nfs_client->cl_trid;
	),

	TP_printk("nfssrv_trid=%u nfsclnt_trid=%u",
		  __entry->nfssrv_trid,
		  __entry->nfsclnt_trid)
);

TRACE_EVENT(nfs_server_clone,
	TP_PROTO(
		const struct nfs_server *server,
		const struct nfs_server *source
	),

	TP_ARGS(server, source),

	TP_STRUCT__entry(
		__field(unsigned int, nfssrv_trid)
		__field(unsigned int, source_nfssrv_trid)
	),

	TP_fast_assign(
		__entry->nfssrv_trid = server->s_sysfs_id;
		__entry->source_nfssrv_trid = source->s_sysfs_id;
	),

	TP_printk("nfssrv_trid=%u source_nfsrv_trid=%u",
		  __entry->nfssrv_trid,
		  __entry->source_nfssrv_trid)
);


TRACE_EVENT(nfs_server_bind_rpc_client,
	TP_PROTO(
		const struct nfs_server *server
	),

	TP_ARGS(server),

	TP_STRUCT__entry(
		__field(unsigned int, nfssrv_trid)
		__field(unsigned int, rpcclient_id)
	),

	TP_fast_assign(
		__entry->nfssrv_trid = server->s_sysfs_id;
		__entry->rpcclient_id = server->client->cl_clid;
	),

	TP_printk("nfssrv_trid=%u client=%u",
		  __entry->nfssrv_trid,
		  __entry->rpcclient_id)
);

DECLARE_EVENT_CLASS(nfs_server_free_class,
	TP_PROTO(
		const struct nfs_server *clp
	),

	TP_ARGS(clp),

	TP_STRUCT__entry(
		__field(unsigned int, nfssrv_trid)
	),

	TP_fast_assign(
		__entry->nfssrv_trid = clp->s_sysfs_id;
	),

	TP_printk("nfssrv_trid=%u", __entry->nfssrv_trid)
);

#define DEFINE_NFS_SERVER_FREE_CLASS(name) \
	DEFINE_EVENT(nfs_server_free_class, name, \
		     TP_PROTO(const struct nfs_server *clp), \
		     TP_ARGS(clp));

DEFINE_NFS_SERVER_FREE_CLASS(nfs_server_free_start);
DEFINE_NFS_SERVER_FREE_CLASS(nfs_server_free_done);

/* NFS fs context */

TRACE_EVENT(nfs_fs_context_new,
	TP_PROTO(
		const struct nfs_fs_context *ctx
	),

	TP_ARGS(ctx),

	TP_STRUCT__entry(
		__field(unsigned int, nfsctx_trid)
	),

	TP_fast_assign(
		__entry->nfsctx_trid = ctx->trid;
	),

	TP_printk("nfsctx_trid=%u", __entry->nfsctx_trid)
);

TRACE_EVENT(nfs_fs_context_parse_param,
	TP_PROTO(
		const struct nfs_fs_context *ctx,
		const char *key,
		const char *value
	),

	TP_ARGS(ctx, key, value),

	TP_STRUCT__entry(
		__field(unsigned int, nfsctx_trid)
		__string(key, key)
		__string(value, value)
	),

	TP_fast_assign(
		__entry->nfsctx_trid = ctx->trid;
		__assign_str_wrap(key, key);
		__assign_str_wrap(value, value);
	),

	TP_printk("nfsctx_trid=%u %s=%s",
		  __entry->nfsctx_trid, __get_str(key), __get_str(value))
);

TRACE_EVENT(nfs_fs_context_log,
	TP_PROTO(
		const struct nfs_fs_context *ctx,
		const char *kind,
		const char *msg
	),

	TP_ARGS(ctx, kind, msg),

	TP_STRUCT__entry(
		__field(unsigned int, nfsctx_trid)
		__string(kind, kind)
		__string(msg, msg)
	),

	TP_fast_assign(
		__entry->nfsctx_trid = ctx->trid;
		__assign_str_wrap(kind, kind);
		__assign_str_wrap(msg, msg);
	),

	TP_printk("nfsctx_trid=%u %s: %s",
		  __entry->nfsctx_trid, __get_str(kind), __get_str(msg))
);

TRACE_EVENT(nfs_fs_context_bind_nfs_server,
	TP_PROTO(
		const struct nfs_fs_context *ctx,
		const struct nfs_server *server
	),

	TP_ARGS(ctx, server),

	TP_STRUCT__entry(
		__field(unsigned int, nfsctx_trid)
		__field(unsigned int, nfssrv_trid)
	),

	TP_fast_assign(
		__entry->nfsctx_trid = ctx->trid;
		__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
	),

	TP_printk("nfsctx_trid=%u nfssrv_trid=%u",
		  __entry->nfsctx_trid,
		  __entry->nfssrv_trid)
);

TRACE_EVENT(nfs_fs_context_dup,
	TP_PROTO(
		const struct nfs_fs_context *ctx,
		const struct nfs_fs_context *source
	),

	TP_ARGS(ctx, source),

	TP_STRUCT__entry(
		__field(unsigned int, nfsctx_trid)
		__field(unsigned int, source_nfsctx_trid)
	),

	TP_fast_assign(
		__entry->nfsctx_trid = ctx->trid;
		__entry->source_nfsctx_trid = source->trid;
	),

	TP_printk("nfsctx_trid=%u source_nfctx_trid=%u",
		  __entry->nfsctx_trid,
		  __entry->source_nfsctx_trid)
);

DECLARE_EVENT_CLASS(nfs_fs_context_free_class,
	TP_PROTO(
		const struct nfs_fs_context *ctx
	),

	TP_ARGS(ctx),

	TP_STRUCT__entry(
		__field(unsigned int, nfsctx_trid)
	),

	TP_fast_assign(
		__entry->nfsctx_trid = ctx->trid;
	),

	TP_printk("nfsctx_trid=%u", __entry->nfsctx_trid)
);

#define DEFINE_NFS_FS_CONTEXT_FREE_CLASS(name) \
	DEFINE_EVENT(nfs_fs_context_free_class, name, \
		     TP_PROTO(const struct nfs_fs_context *ctx), \
		     TP_ARGS(ctx));

DEFINE_NFS_FS_CONTEXT_FREE_CLASS(nfs_fs_context_free_start);
DEFINE_NFS_FS_CONTEXT_FREE_CLASS(nfs_fs_context_free_done);

/* mount syscall */

TRACE_EVENT(mount_new,
	TP_PROTO(
		const char *fs_type,
		const char *mount_dir
	),

	TP_ARGS(fs_type, mount_dir),

	TP_STRUCT__entry(
		__string(fs_type, fs_type)
		__string(mount_dir, mount_dir)
	),

	TP_fast_assign(
	        __assign_str_wrap(fs_type, fs_type);
	        __assign_str_wrap(mount_dir, mount_dir);
	),

	TP_printk("type=%s dir=%s", __get_str(fs_type), __get_str(mount_dir))
);

TRACE_EVENT(nfs_initiate_rw_jobid,
	TP_PROTO(
		const struct nfs_pgio_header *hdr,
		const char *job_id,
		const char *action
	),

	TP_ARGS(hdr, job_id, action),

	TP_STRUCT__entry(
		__field(dev_t, dev)
		__field(unsigned int, nfssrv_trid)
		__field(u32, fhandle)
		__field(u64, fileid)
		__field(loff_t, offset)
		__field(u32, count)
		__string(jobid, job_id ?: "")
		__string(action, action)
	),

	TP_fast_assign(
		const struct inode *inode = hdr->inode;
		const struct nfs_server *server = NFS_SERVER(inode);
		const struct nfs_inode *nfsi = NFS_I(inode);
		const struct nfs_fh *fh = hdr->args.fh ?
					  hdr->args.fh : &nfsi->fh;

		__entry->offset = hdr->args.offset;
		__entry->count = hdr->args.count;
		__entry->dev = inode->i_sb->s_dev;
		__entry->nfssrv_trid = server ? server->s_sysfs_id : 0;
		__entry->fileid = nfsi->fileid;
		__entry->fhandle = nfs_fhandle_hash(fh);
		__assign_str_wrap(jobid, job_id ?: "");
		__assign_str_wrap(action, action);
	),

	TP_printk(
		"nfssrv_trid=%u fileid=%02x:%02x:%llu fhandle=0x%08x "
		"offset=%lld count=%u jobid=%s action=%s",
		__entry->nfssrv_trid,
		MAJOR(__entry->dev), MINOR(__entry->dev),
		(unsigned long long)__entry->fileid,
		__entry->fhandle,
		(long long)__entry->offset,
		__entry->count,
		__get_str(jobid),
		__get_str(action)
	)
);

#endif /* _TRACE_NFS_H */

#undef TRACE_INCLUDE_PATH
#define TRACE_INCLUDE_PATH .
#define TRACE_INCLUDE_FILE nfstrace
/* This part must be outside protection */
#include <trace/define_trace.h>
